push.on('registration', function(data) {
	user_push_token 	= data.registrationId;

	if(user_id !== null){
		var post_data = "actions=update_push_token&user_id="+user_id+"&device=android&token="+data.registrationId;	
		query_server(post_data, "GET", "push_token_update_result");
	}
});

push.on('notification', function(data) {
    // data.message,
    // data.title,
    // data.count,
    // data.sound,
    // data.image,
    // data.additionalData
    if(data.type == payTax){
    	user_status 	= 0;
    	user_pay_tax_page();
    }

    //ride request
    if(data.type == 1){
    	var title 		= data.title;
    	var content 	= data.message+
    					  '<a href="#" data-link="accept_ride_request?driver='+user_id+'&user='+data.sender+'&id='+data.trip_id+'" class="btn btn-info"><i class="fa fa-check"></i> ACCEPT</a>'+
    					  '<a href="#" data-link="decline_ride_request?driver='+user_id+'&user='+data.sender+'&id='+data.trip_id+'" class="btn btn-danger"><i class="fa fa-times"></i> DECLINE</a>'+
    	load_modal(content, title);
    }

    listData =   '<article id="chat-id-" class="chat-item left">'+
                  '<a href="#" class="pull-left thumb-sm avatar"><img src="images/avatar_default.jpg" class="img-circle"></a>'+
                  '<section class="chat-body">'+
                  '<div class="panel b-light text-sm m-b-none">'+
                  '<div class="panel-body">'+
                  '<span class="arrow left"></span>'+
                  '<p class="m-b-none">'+data.message+'</p>'+
                  '</div>'+
                  '</div>'+
                  /*'<small class="text-muted"><i class="fa fa-ok text-success"></i> 2 minutes ago</small>'+*/
                  '</section>'+
                  '</article>';

	$(".chat-"+data.chat_id).append(listData);
	save_message(user_id, data.responder, data.chat_id, data.responder_name, data.message, short_today_date, 0, 1);
});

push.on('error', function(e) {
    // e.message
});