

var form_submitted      = 0;

//var template_url    = "http://127.0.0.1/secure/desktop/template/";
var template_url        = "template/";

var level_description   = ["", "super_administrator", "administrator", "teacher", "finance", "student", "parent"];

var deploy_device       = "desktop"; //desktop/mobile

var current_form;
var user_profile, user_level, user_description, user_name, user_id, user_client_id, user_client, user_channel_id, user_push_token;

var isPhoneGapReady     = false;
var isAndroid           = false;
var isBlackberry        = false;
var isIphone            = false;
var isWindows           = false;

// NETWORK STATUS
var isConnected         = false;
var isHighSpeed         = false;
var internetInterval;

var currentUrl;
var currentPage;
var current_form        = "";

var pushNotification, latestMessage;
var device_platform, device_model, device_version, device_uuid;
var connection_type; 

var invite_name, invite_mobile;
var httpReq             = null;

var watch_transaction_sms   = 0;
var ecocash_service_center  = "+263770010502";
var telecash_service_center = "xxxxxx";

var ecocash_sender          = "+263164";
var telecash_sender         = "xxxx";

var full_date               = new Date();
var year_date               = full_date.getFullYear();
var month_date              = full_date.getMonth();
var day_date                = full_date.getDate();
var pusher;

var sys_year, sys_term;

var tab_history = [];

if(deploy_device == "desktop"){
  var session             = window.sessionStorage.getItem("session");
}

if(deploy_device == "mobile"){
  var session             = window.localStorage.getItem("session");
  var er_sound            = new Media("/android_asset/www/beep.wav");
  var msg_sound           = new Media("/android_asset/www/beep.wav");
}

if (window.history && window.history.pushState) {
  console.log("HISTORY STATE WORKS");
  //window.history.pushState('forward', null, './#forward');

  $(window).on('popstate', function() {
    var page = tab_history[tab_history.length - 1];
    if(page == undefined){
    }else{
      loadingShow();
      var variables       = page.slice(page.indexOf('?') + 1).split('&');
      var num_variables   = variables.length;
      var url             = page.substr(0, page.indexOf('?'));
      
      if(url == "")
        actions = page.replace(".php", "_page");
      else
        actions = url.replace(".php", "_page");
      
      if ( typeof window[actions] == 'function') {
        if(num_variables > 0){
          window[actions](variables);
        }else{
          window[actions]();
        }
      }
      tab_history.pop();
      return false;
    }
    
    //alert('Back button was pressed.');
  });
}

if(session){
  var details           = $.parseJSON(atob(session));
  user_level            = details.level;
  user_description      = level_description[user_level];
  user_name             = details.name+" "+details.surname;
  user_id               = details.ID;
  user_client_id        = details.client_id;
  user_client           = details.client;
  user_profile          = details.profile;
  $(".profile-cog").removeClass('hide');
  
  if(deploy_device == "mobile"){
    user_push_token         = details.token;
  }
  if(user_level == 1 || user_level == 2 || user_level == 3 || user_level == 4){
    $(".dker").removeClass("hide");
  }
  /*console.log("USER_ID="+user_id);
  console.log("USER_NAME="+user_name);
  console.log("USER_LEVEL="+user_level);
  console.log("USER_DESCRIPTION="+user_description);*/
}

function terminate_session(){
  if(deploy_device == "desktop"){
    window.sessionStorage.removeItem("session");
    document.title = "SIGN IN";
  }else{
    window.localStorage.removeItem("session");
    document.title = "SIGN IN";
  }
}

function err_string(err){
  var string =  '<span class="fa-stack fa-2x pull-left m-r-sm">'+
                '<i class="fa fa-circle fa-stack-2x text-danger"></i>'+
                '<i class="fa fa-times fa-stack-1x text-white"></i>'+
                '</span>'+
                '<div class="clear"><p>'+err+'</p></div>';
  return string;
}

function success_string(err){
  var string =  '<span class="fa-stack fa-2x pull-left m-r-sm">'+
                '<i class="fa fa-circle fa-stack-2x text-success"></i>'+
                '<i class="fa fa-check fa-stack-1x text-white"></i>'+
                '</span>'+
                '<div class="clear"><p>'+err+'</p></div>';
  return string;
}

function info_string(err){
  var string =  '<span class="fa-stack fa-2x pull-left m-r-sm">'+
                '<i class="fa fa-circle fa-stack-2x text-info"></i>'+
                '<i class="fa fa-info fa-stack-1x text-white"></i>'+
                '</span>'+
                '<div class="clear"><p>'+err+'</p></div>';
  return string;
}

function smarter_processing(err){
  var string =  '<img src="images/smarter_small.png">'+
                '<div class="clear text-center-xs"><p><img src="images/loaders/roller.gif" >  '+err+'</p></div>';
  return string;
}

function emergency_string(err){
  var string =  '<span class="fa-stack fa-2x pull-left m-r-sm">'+
                '<i class="fa fa-circle fa-stack-2x text-danger"></i>'+
                '<i class="fa fa-bullhorn fa-stack-1x text-white"></i>'+
                '</span>'+
                '<div class="clear"><p>'+err+'</p></div>';
  return string;
}

function message_string(err){
  var string =  '<span class="fa-stack fa-2x pull-left m-r-sm">'+
                '<i class="fa fa-circle fa-stack-2x text-primary"></i>'+
                '<i class="fa fa-envelope fa-stack-1x text-white"></i>'+
                '</span>'+
                '<div class="clear"><p>'+err+'</p></div>';
  return string;
}

function advert_string(client, msg, title, img){
  var string =  '<article class="media">'+
                '<span class="pull-left thumb-md"><img src="'+img+'"></span>'+
                '<div class="media-body">'+
                '<h4>'+title+'</h4>'+
                '<small class="block">'+client+'</small>'+
                '<small class="block m-t-sm">'+msg+'</small>'+
                '</div>'+
                '</article>';
  return string;
}

function retract_menu(){
  if($(".mobile-menu-btn").hasClass('active')){
    $(".mobile-menu-btn").click();
  } 
}

//QUERY
function query_server(post_data, method, result){
  if(method == "POST"){
    $.post(request_url+"?data="+btoa(post_data), function(data) {
      console.log(data);
      $('#submit').prop("disabled", false);
      $(".form-progress").addClass("hide");
      $(".navbar-brand").html(user_client);
      
      try{
        var info = $.parseJSON(data);
        $.each(info, function(k, v) { 
          console.log(k+" - "+v);
        }); 
        window[result](info); 
        retract_menu();
      }catch(err){
        load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
        retract_menu();
        console.log(err);
      }
    }).fail(function(data) {
      retract_menu();
      load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
      console.log("ERROR POSTING DETAILS"); 
    });    
  }

  if(method == "GET"){
    $.post(request_url+"?data="+btoa(post_data), function(data) {
      console.log(data);
      $('#submit').prop("disabled", false);
      $(".form-progress").addClass("hide");

      try{
        var info = $.parseJSON(data);
        $.each(info, function(k, v) { 
          console.log(k+" - "+v);
        }); 
        window[result](info);
      }catch(err){
        load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
        console.log(err);
      }
    }).fail(function(data) {
      retract_menu();
      load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
      console.log("ERROR POSTING DETAILS"); 
    });    
  }
}

function page_loader_show(msg){
}

function page_loader_hide(msg){
}

function responder_info_window(name, surname, account, company){
  '<div id="content">'+
  '<div id="siteNotice">'+
  '</div>'+
  '<h1 id="firstHeading" class="firstHeading">'+name+' '+surname+'</h1>'+
  '<div id="bodyContent"><p>'+
  '<b>RESPONDER #: </b>'+account+' <br> ' +
  '<b>COMPANY: </b>'+company+' <br> ' +
  '</p></div>'+
  '</div>';
}

//**********MAP DIRECTIONS**********//
function desktop_geolocation(){
  if(navigator.geolocation) {
    browserSupportFlag = true;
    navigator.geolocation.getCurrentPosition(function(position) {
      initialLocation = new google.maps.LatLng(position.coords.latitude,position.coords.longitude);
      map.setCenter(initialLocation);
    }, function() {
      handleNoGeolocation(browserSupportFlag);
    });
  }
}

//**********LOGIN / LOGOUT**********//

function login_modal(){
  $('#ajaxModal').remove();
  var $remote  = "modal.lockme.html";
  var $modal   = $('<div class="modal" id="ajaxModal"><div class="modal-body"></div></div>');  
  $('body').append($modal);
  $modal.modal();
  $modal.load($remote);
  //TERMINATE SESSION
  terminate_session();
  document.title = "SIGN IN";
}

function load_modal(content, title){
  $('#ajaxModal').remove();
  var $remote  = "modal.html";
  var $modal   = $('<div class="modal" id="ajaxModal"><div class="modal-body"></div></div>');
  $('body').append($modal);
  $modal.modal();
  $modal.load($remote, function(){
    $(".modal-title").html(title);
    $(".modal-body").html(content);
    //CONFIRM EMERGENCY CALL
    $(".modal-body").on('click', "a", function(e){      
        var page = $(this).attr("data-link");
        if(page == undefined){
          //alert("link un defined");
        }else{
          loadingShow();
          var variables       = page.slice(page.indexOf('?') + 1).split('&');
          var num_variables   = variables.length;
          var url             = page.substr(0, page.indexOf('?'));
          
          if(url == "")
            actions = page.replace(".php", "_page");
          else
            actions = url.replace(".php", "_page");
          
          if ( typeof window[actions] == 'function') {
            if(num_variables > 0){
              window[actions](variables);
            }else{
              window[actions]();
            }
          }
  
          return false;
        }
    });    
  });  
}

function calendar_modal(content, title){
  $('#ajaxModal').remove();
  var $remote  = "modal.html";
  var $modal   = $('<div class="modal" id="ajaxModal"><div class="modal-body"></div></div>');
  $('body').append($modal);
  $modal.modal();
  $modal.load($remote, function(){
    $(".modal-title").html(title);
    $(".modal-body").html(content);
    //CONFIRM EMERGENCY CALL
    $(".modal-body").on('click', "a", function(e){      
        var page = $(this).attr("data-link");
        if(page == undefined){
          //alert("link un defined");
        }else{
          loadingShow();
          var variables       = page.slice(page.indexOf('?') + 1).split('&');
          var num_variables   = variables.length;
          var url             = page.substr(0, page.indexOf('?'));
          
          if(url == "")
            actions = page.replace(".php", "_page");
          else
            actions = url.replace(".php", "_page");
          
          if ( typeof window[actions] == 'function') {
            if(num_variables > 0){
              window[actions](variables);
            }else{
              window[actions]();
            }
          }
  
          return false;
        }
    });    
  });  
}

function comment_modal(id, level){
  $('#ajaxModal').remove();
  var $remote  = "modal.html";
  var $modal   = $('<div class="modal" id="ajaxModal"><div class="modal-body"></div></div>');
  $('body').append($modal);
  $modal.modal();
  $modal.load($remote, function(){
    $("#id").val(id);
    $("#level").val(level);

    //SEARCH TRANSACTIONS
    $(".modal-body").on('submit', '#submit_comment', function(e) {
      var current_form = "#"+$(this).attr('id');
      $(current_form+" #submit").prop("disabled", true);   
      $(current_form+" .form-progress").removeClass("hide");      
      //validate
      $(current_form+' .required_field').each(function(i){
                 
        if($(this).val() == ''){
          var err_message = $(this).attr('data_error');
          $('#submit').prop("disabled", false);  
          $(".form-progress").addClass("hide");
          load_modal(info_string(err_message), "SEARCH PARENTS");
          return false;            
        }
              
        if(i == $(current_form+' .required_field').length - 1){
          var post_data     = $(current_form).serialize();
          query_server(post_data, "POST", "comment_topic");
          close_modal();         
        }       
      });
        
      return false;
    });    
  });  
}

function video_modal(video){
  $('#ajaxModal').remove();
  var $remote  = "modal.html";
  var $modal   = $('<div class="modal" id="ajaxModal"><div class="modal-body"></div></div>');
  $('body').append($modal);
  $modal.modal();
  $modal.load($remote, function(){
    var listData = '<video width="100%" height="auto" autoplay><source src="'+video+'" type="video/mp4"></video>';
    $(".modal-title").html("ASSIGNMENT VIDEO");
    $(".modal-body").html(listData);
        
  });  
}

function close_modal(){
  $('#ajaxModal').remove();
  $('.modal-backdrop').remove();
  $("body").removeClass("modal-open");
}

$(document).on('click', '[data-dismiss="modal"]',
  function(e) {
    close_modal();
  }
);

//**********SESSION LOGIN / LOGOUT**********//

function session_countdown(){
  //session lockout
  this.addEventListener("mousemove", resetTimer, false);
  this.addEventListener("mousedown", resetTimer, false);
  this.addEventListener("keypress", resetTimer, false);
  this.addEventListener("DOMMouseScroll", resetTimer, false);
  this.addEventListener("mousewheel", resetTimer, false);
  this.addEventListener("touchmove", resetTimer, false);
  this.addEventListener("MSPointerMove", resetTimer, false);

  startTimer();
}

function startTimer() {
    timeoutID = window.setTimeout(
      function logout(){
        $('#load_content').load("modal.lockme.html", function(){
          $(".header").addClass("hide");
          $("#nav").addClass("hide");
          terminate_session();
        });
      }, 
      15*60000 // wait 15 minutes before calling Logout
    );
}
 
function resetTimer(e) {
    window.clearTimeout(timeoutID);   
    //goActive();
    startTimer();
}

function goInactive(){
    $('#load_content').load("modal.lockme.html", function(){
      $(".header").addClass("hide");
      $("#nav").addClass("hide");
      terminate_session();
    });
}

//**********MENUS**********//

function user_side_menu(){
  $(".nav-primary").load("menu.html");
}