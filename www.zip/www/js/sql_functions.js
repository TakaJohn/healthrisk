var db = window.openDatabase("zibhegi", "1.0", "zibhegi database", 1000000);
db.transaction(
	function populateDB(tx) {
		tx.executeSql('CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, uuser_id INTEGER, message TEXT, from INTEGER, to INTEGER, date TEXT, status INT, state INT)');
		tx.executeSql('CREATE TABLE IF NOT EXISTS chats (uuser_id INTEGER, name TEXT)');
		tx.executeSql('CREATE TABLE IF NOT EXISTS users (ID INTEGER PRIMARY KEY, level INTEGER, name TEXT, surname TEXT, client_id INTEGER, client TEXT, token TEXT)');
		tx.executeSql('CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, bid_id INTEGER, status INT)');
		//tx.executeSql('INSERT INTO users (id, nname, surname, mobile, email, medaid, medaidnumber, bloodtype, allergies, disabilities, regdate) VALUES ("1", 1, "Test", "Client", "address", "", "", "", 0)');
	}, 
	function errorCB(err) {
		console.log("Error processing SQL: " + err.code);
	}, 
	function successCB() {
		console.log("Database successfully populated")
	}
);

//save offline payments
function save_offline_payments(bid_id){
	db.transaction(function(tx) {
	 	tx.executeSql(
	 		"INSERT offline_bid_payments (bid_id, status) VALUES (?, ?)", [bid_id, 0], 
	 		function success(){
	 			console.log("offline payment saved");
	 		}, 
	 		function error(tx,err){
	 			console.log(err.message);
	 		}
	 	);
	});	
}

//update offline payments
function update_offline_payments(id){
	db.transaction(function(tx) {
	 	tx.executeSql(
	 		"UPDATE offline_bid_payments SET status = ? WHERE bid_id = ?", [1, id], 
	 		function success(){
	 			console.log("offline payment updated");
	 		}, 
	 		function error(tx,err){
	 			console.log(err.message);
	 		}
	 	);
	});	
}

//get offline payments
function send_offline_bid_payments(){
	db.transaction(function(tx) {
	 	tx.executeSql(
	 		"SELECT * FROM offline_bid_payments WHERE status = ? ", [0], 
	 		function success(tx, results){
	 			var len = results.rows.length;
			    if(len !== 0){
			    	for (var i = 0; i < len; i++){
			    		var bidId 		= results.rows.item(i).bid_id;
			    		var post_data   = "action=confirm_bid_payment&id="+bidId+"&user_id="+user_id;
			    		query_server(post_data, "POST", "offline_bid_payments_result");
		    		}
			    }
	 		}, 
	 		function error(tx,err){
	 			console.log(err.message);
	 		}
	 	);
	});	
}

//SAVE CHATS
function save_chat(uuser_id, name){
	db.transaction(function(tx) {
	 	tx.executeSql(
	 		"INSERT IGNORE INTO chats (uuser_id, name) VALUES (?, ?)", [uuser_id, name], 
	 		function success(){
	 			console.log("chat saved");
	 		}, 
	 		function error(tx,err){
	 			console.log(err.message);
	 		}
	 	);
	});	
}

//save chat message
function save_message(uuser_id, from, to, message, date, status, state){
	db.transaction(function(tx) {
	 	tx.executeSql(
	 		"INSERT INTO messages (uuser_id, from, to, message, date, status, state) VALUES (?, ?, ?, ?, ?, ?, ?)", [uuser_id, from, to, message, date, status, state], 
	 		function success(){
	 			console.log("message successfully saved");
	 		}, 
	 		function error(tx,err){
	 			console.log(err.message);
	 		}
	 	);
	});	
}

//get chat list
/*function get_chats(){
	 db.transaction(function(tx) {
	 	tx.executeSql(
	 		"SELECT * FROM chats", [], 
	 		function success(tx, results){
	 			var len = results.rows.length;
			    if(len !== 0){
			    	listData = "";
			    	for (var i = 0; i < len; i++){
			    		var chat_name 		= results.rows.item(i).name;
			    		var chat_user_id 	= results.rows.item(i).user_id;
			    		db.transaction(function(tx) {
						 	tx.executeSql(
						 		"SELECT message FROM messages WHERE to = ? OR from = ? ORDER BY id LIMIT 1", [results.rows.item(i).user_id], 
						 		function success(){
						 			var len = results.rows.length;
						 			if(len !== 0){
						 				listData +=   "<li class='list-group-item'>"+
						                              "<div class='media'>"+
						                              "<a href='#' id='chat-messages' uuser_id='"+chat_user_id+"'>"+
						                              "<span class='pull-left thumb-sm'><img src='images/avatar_default.jpg' class='img-circle'></span>"+
						                              "<div class='pull-right text-success m-t-sm'><i class='fa fa-circle'></i></div>"+
						                              "<div class='media-body'>"+
						                              "<div>"+chat_name+"</div>"+
						                              "<small class='text-muted'>"+results.rows.item(i).message+"</small><br>"+
						                              "<small class='text-muted'>"+results.rows.item(i).date+"</small>"+		                              
						                              "</div>"+
						                              "</a>"+
						                              "</div>"+
						                              "</li>";
						 			}
						 		}, 
						 		function error(tx,err){
						 			//console.log(err.message);
						 		}
						 	);
						});
		    		}
		    		$(".chats-list").html(listData);
			    }
	 		}, 
	 		function error(tx,err){
	 			console.log(err.message);
	 		}
	 	);
	 });	
}*/

function get_chats(){
	 db.transaction(function(tx) {
	 	tx.executeSql(
	 		"SELECT chats.uuser_id, chats.name, messages.id, messages.message, messages.date FROM chats, messages WHERE chats.uuser_id = messages.uuser_id GROUP BY chats.user_id ORDER BY messages.id", [], 
	 		function success(tx, results){
	 			var len = results.rows.length;
			    if(len !== 0){
			    	listData = "";
			    	for (var i = 0; i < len; i++){
			    		listData +=   "<li class='list-group-item'>"+
		                              "<div class='media'>"+
		                              "<a href='#' id='chat-messages' uuser_id='"+results.rows.item(i).uuser_id+"'>"+
		                              "<span class='pull-left thumb-sm'><img src='images/avatar_default.jpg' class='img-circle'></span>"+
		                              "<div class='pull-right text-success m-t-sm'><i class='fa fa-circle'></i></div>"+
		                              "<div class='media-body'>"+
		                              "<div>"+results.rows.item(i).name+"</div>"+
		                              "<small class='text-muted'>"+results.rows.item(i).message+"</small><br>"+
		                              "<small class='text-muted'>"+results.rows.item(i).date+"</small>"+		                              
		                              "</div>"+
		                              "</a>"+
		                              "</div>"+
		                              "</li>";
		    		}
		    		$(".chats-list").html(listData);
			    }
	 		}, 
	 		function error(tx,err){
	 			console.log(err.message);
	 		}
	 	);
	 });	
}

//get chat list
function get_chat_messages(uuser_id){
	 db.transaction(function(tx) {
	 	tx.executeSql(
	 		"SELECT * FROM messages WHERE uuser_id = ? ORDER BY id", [uuser_id], 
	 		function success(tx, results){
	 			var len = results.rows.length
			    if(len !== 0){
			    	listData = "";
			    	for (var i = 0; i < len; i++){
			    		if(results.rows.item(i).to == uuser_id){
				    		listData +=   '<article id="chat-id-"'+i+' class="chat-item right">'+
				                          '<a href="#" class="pull-right thumb-sm avatar"><img src="images/avatar_default.jpg" class="img-circle"></a>'+
				                          '<section class="chat-body">'+
				                          '<div class="panel bg bg-primary text-sm m-b-none">'+
				                          '<div class="panel-body">'+
				                          '<span class="arrow right"></span>'+
				                          '<p class="m-b-none">'+results.rows.item(i).message+'</p>'+
				                          '</div>'+
				                          '</div>'+
				                          /*'<small class="text-muted"><i class="fa fa-ok text-success"></i> 2 minutes ago</small>'+*/
				                          '</section>'+
				                          '</article>';
                        }else{
                        	listData +=   '<article id="chat-id-"'+i+' class="chat-item left">'+
				                          '<a href="#" class="pull-left thumb-sm avatar"><img src="images/avatar_default.jpg" class="img-circle"></a>'+
				                          '<section class="chat-body">'+
				                          '<div class="panel b-light text-sm m-b-none">'+
				                          '<div class="panel-body">'+
				                          '<span class="arrow left"></span>'+
				                          '<p class="m-b-none">'+results.rows.item(i).message+'</p>'+
				                          '</div>'+
				                          '</div>'+
				                          /*'<small class="text-muted"><i class="fa fa-ok text-success"></i> 2 minutes ago</small>'+*/
				                          '</section>'+
				                          '</article>';
                        }
		    		}
		    		$(".chat-messages-list").html("<div class='chat-"+uuser_id+"'>"+listData+"</div>");
			    }
	 		}, 
	 		function error(tx,err){
	 			console.log(err.message);
	 		}
	 	);
	 });	
}

//get contacts
function get_contacts(){
	var phonebook_contact = [];
	var options = new ContactFindOptions();
    options.filter = "";
    options.multiple = true;
    var fields = ["displayName", "phoneNumbers", "name"];
    navigator.contacts.find(
    	fields, 
    	function success(contacts){
    		var listData = "";
		    for (var i = 0; i < contacts.length; i++) {
		    	if(contacts[i].phoneNumbers){
		    		for (var x = 0; x < contacts[i].phoneNumbers.length; x++) {
		    			var contact_name;
		    			var mobile;
		    			if(contacts[i].displayName == undefined || contacts[i].displayName == null){
		    				mobile = contacts[i].phoneNumbers[x].value;
		    				contact_name = contacts[i].name;
		    				phonebook_contact.push(contact_name+"|"+mobile);
		    				//save_contacts(contact_name, mobile);
		    			}else{
		    				mobile = contacts[i].phoneNumbers[x].value;
		    				contact_name = contacts[i].displayName;
		    				phonebook_contact.push(contact_name+"|"+mobile);
		    				//save_contacts(contact_name, mobile);
		    			}
		    		}
		    	}
		    }

		    phonebook_contact.sort();
		    setTimeout(function(){	
		    	var listData	= "";
		    	for (var i = 0; i < phonebook_contact.length; i++) {
					var spliter = phonebook_contact[i].indexOf("|");
					var name 	= phonebook_contact[i].slice(0, spliter);
					var mobile 	= phonebook_contact[i].slice(spliter + 1, phonebook_contact[i].length);

					listData += '<li class="list-group-item">'+
		                          '<div class="media">'+
		                          '<a href="#" id="invite-friend" data-name="'+name+'" data-mobile="'+mobile.replace(/\ /g, '')+'" class="'+mobile.replace(/\ /g, '')+'">'+
		                          '<span class="pull-left thumb-sm"><img src="images/avatar_default.jpg" alt="" class="img-circle"></span>'+
		                          '<div class="pull-right text-success m-t-sm invite-status"></div>'+
		                          '<div class="media-body">'+
		                          '<div>'+name+'</div>'+
		                          '<small class="text-muted">'+mobile.replace(/\ /g, '')+'</small>'+
		                          '</div>'+
		                          '</a>'+
		                          '</div>'+
		                          '</li>';
		    	}
				$(".phonebook-list").html(listData);
				$(".phonebook .panel-heading").html(phonebook_contact.length+" Contacts");
			}, 2000);
		    
    	}, 
    	function failure(){
    		$(".phonebook .panel-heading").html("Error getting your contacts");
    	}, 
    	options
    );	
}