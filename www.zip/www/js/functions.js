$(document).on("click", "#pay-bid", function(){
  var number    = $(this).attr("data-number");  // receiver
  var bid       = $(this).attr("data-bid");     // bid id
  var amount    = $(this).attr("data-amount");  // bid amount

  window.plugins.CallNumber.callNumber(
    function(success) {
      startWatch();                             // start watching sms
    }, 
    function(err) {  
      console.log("Error making call"+err);
    }, 
    "*151*1*1*"+number+"*"+amount+"%23" //"*151*2*2*30106*"+amount+"%23"
  );

  return false;
});

function user_side_menu(){
  switch(user_role) {
      case 1: //system administrator
          $(".nav-settings").removeClass("hide");
          $(".nav-claims").removeClass("hide");
          $(".nav-patients").removeClass("hide");
          $(".nav-submissions").removeClass("hide");
        break;
      case 2: // administrator
          $(".nav-settings").removeClass("hide");
          $(".nav-claims").removeClass("hide");
          $(".nav-patients").removeClass("hide");
          $(".nav-submissions").removeClass("hide");
        break;
  }
}


//users

function users_page(){
  switch(user_role){
    case 1: // system administrator
        pageLoadingShow();
        post_data         = "actions=users";
        $.post(
          request_url+"?data="+btoa(post_data), 
          function(data) {
            pageLoadingHide();
            try{
              var data = $.parseJSON(data);
              switch(data.query_status){
                case 0:
                  load_modal(err_string(data.msg), data.action_title);
                  break;
                case 1:
                  $('.load-content').load('template/users.html', function(){          
                    $('.load-content').scrollTop(0);
                    document.title = "Users";

                    if(data.users){
                      listData      = "";
                      $.each(data.users, function(k, v) {
                        listData += '<tr>'+
                                    '<td>'+v.name+'</td>'+
                                    '<td>'+v.role+'</td>'+
                                    '<td>'+v.status+'</td>'+
                                    '<td>'+v.view+'</td>'+
                                    '</tr>';
                      });
                      $(".users-grid").html(listData);
                      $(".users-table").DataTable({
                        "sDom": "<'row'<'col-sm-6'l><'col-sm-6'f>r>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
                        "sPaginationType": "full_numbers"
                      });
                    }
                    
                  });
                  break;
                case 2:
                  load_modal(info_string(data.msg), data.action_title);
                  break;
              }
            }catch(err){
              load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
            }
          }
        ).fail(function(data) {
          pageLoadingHide();
          load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
        });
      break;
    case 2: // administrator
        pageLoadingShow();
        post_data         = "actions=users";
        $.post(
          request_url+"?data="+btoa(post_data), 
          function(data) {
            pageLoadingHide();
            try{
              var data = $.parseJSON(data);
              switch(data.query_status){
                case 0:
                  load_modal(err_string(data.msg), data.action_title);
                  break;
                case 1:
                  $('.load-content').load('template/users.html', function(){          
                    $('.load-content').scrollTop(0);
                    document.title = "Users";

                    if(data.users){
                      listData      = "";
                      $.each(data.users, function(k, v) {
                        listData += '<tr>'+
                                    '<td>'+v.name+'</td>'+
                                    '<td>'+v.role+'</td>'+
                                    '<td>'+v.status+'</td>'+
                                    '<td>'+v.view+'</td>'+
                                    '</tr>';
                      });
                      $(".users-grid").html(listData);
                      $(".users-table").DataTable({
                        "sDom": "<'row'<'col-sm-6'l><'col-sm-6'f>r>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
                        "sPaginationType": "full_numbers"
                      });
                    }
                    
                  });
                  break;
                case 2:
                  load_modal(info_string(data.msg), data.action_title);
                  break;
              }
            }catch(err){
              load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
            }
          }
        ).fail(function(data) {
          pageLoadingHide();
          load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
        });
      break;
    default:
      load_modal(err_string("PERMISSION DENIED"), "ERROR");
  }
}

function user_details_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "id"){
      var id = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  pageLoadingShow();
  post_data         = "actions=user_details&user_id="+user_id+"&id="+id;
  $.post(
    request_url+"?data="+btoa(post_data), 
    function(data) {
      pageLoadingHide();
      try{
        var data = $.parseJSON(data);
        switch(data.query_status) {
            case 0:
                load_modal(err_string(data.msg), data.action_title);
                break;
            case 1:
                $('.load-content').load('template/user_details.html', function(){
                  $('.load-content').scrollTop(0);
                  document.title = "USER DETAILS";

                  //users details
                  if(data.details){
                    $("input[name='id']").val(data.details.id);
                    $("input[name='account']").val(data.details.account);
                    $("select[name='title']").val(data.details.title);
                    $("input[name='name']").val(data.details.name);
                    $("input[name='surname']").val(data.details.surname);
                    $("input[name='birthdate']").val(data.details.birthdate);
                    $("input[name='nationalId']").val(data.details.nationalId);

                    $("input[name='address']").val(data.details.address);
                    $("input[name='area']").val(data.details.area);
                    $("input[name='city']").val(data.details.city);
                    $("input[name='phone']").val(data.details.phone);
                    $("input[name='mobile']").val(data.details.mobile);
                    $("input[name='email']").val(data.details.email);

                    $("select[name='region']").val(data.details.region);

                    $("select[name='level']").val(data.details.level);

                    $("select[name='status']").val(data.details.status);

                  }
                });
                break;
            case 2:
                load_modal(info_string(data.msg), data.action_title);
                break;
            default:
                load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
        }

      }catch(err){
        load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
        $(".navbar-brand").html(user_client);
        
      }
    }
  ).fail(function(data) {
    pageLoadingHide();    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function update_user_result(data){
  $('#submit').prop("disabled", false);
  $(".form-progress").addClass("hide");

  if(data){
    switch(data.query_status) {
        case 0:
            load_modal(err_string(data.msg), data.action_title);
            break;
        case 1:
            load_modal(success_string(data.msg), data.action_title);
            break;
        case 2:
            load_modal(info_string(data.msg), data.action_title);
            break;
        default:
            load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER"), "ERROR");      
    } 
  }else{
    load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER.."), "ERROR");
  }
}

//settings

function settings_page(){
  switch(user_role){
    case 1: // system administrator
        pageLoadingShow();
        post_data         = "actions=settings_form";
        $.post(request_url+"?data="+btoa(post_data), function(data) {
          pageLoadingHide();
          try{
             
            switch(data.query_status){
              case 0:
                load_modal(err_string(data.msg), data.action_title);
                break;
              case 1:
                $('.load-content').load('template/settings.html', function(){          
                  $('.load-content').scrollTop(0);
                  document.title = "Settings";

                  $('.datepicker-input').datepicker();
                  ajax_uploader();

                  $("#user_id").val(user_id);
                  $("#update_company_financials #user_id").val(user_id);
                  $("#update_company_communications #user_id").val(user_id);
                  $("#update_company_smarter #user_id").val(user_id);

                  details   = data.settings.details;
                  if(details.hasOwnProperty("logo")){
                    $("#logo").html(details.logo);
                    if(details.logo){
                      $("#logo").val(details.logo);
                      $(".logo-pic").html('<img width="100%" class="logo-image" src="../logo/'+details.logo+'">');
                    }
                  }

                  $("input[name='name']").val(details.name);
                  $("input[name='address']").val(details.address);
                  $("input[name='area']").val(details.area);
                  $("input[name='city']").val(details.city);
                  $("input[name='phone']").val(details.phone);
                  $("input[name='mobile']").val(details.mobile);
                  $("input[name='email']").val(details.email);

                  if(data.settings.communications){
                    var communications = data.settings.communications;
                    $("input[name='smtp_host']").val(communications.smtp_host);
                    $("input[name='smtp_port']").val(communications.smtp_port);
                    $("input[name='smtp_username']").val(communications.smtp_username);
                    $("input[name='smtp_password']").val(communications.smtp_password);
                    $("input[name='sms_username']").val(communications.sms_username);
                    $("input[name='sms_password']").val(communications.sms_password);
                    $("input[name='admin_email']").val(communications.admin_email);
                    $("input[name='marketing_email']").val(communications.marketing_email);
                  }
                  
                  if(data.settings.financials){
                    var financials = data.settings.financials;
                    $("input[name='sales_tax']").val(financials.sales_tax);
                    $("input[name='vat_number']").val(financials.vat_number);
                    $("input[name='bank']").val(financials.bank);
                    $("input[name='account_number']").val(financials.account_number);
                    $("input[name='account_name']").val(financials.account_name);
                    $("input[name='branch']").val(financials.branch);
                  }
                  
                });
                break;
              case 2:
                load_modal(info_string(data.msg), data.action_title);
                break;
            }
          }catch(err){
            load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
          }
        }).fail(function(data) {
          pageLoadingHide();
          load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
        });
      break;
    case 2: // administrator
      break;
    default:
      load_modal(err_string("PERMISSION DENIED"), "ERROR");
  }
}

function update_company_details_result(data){
  $('#submit').prop("disabled", false);
  $(".form-progress").addClass("hide");

  if(data){
    switch(data.query_status) {
        case 0:
            load_modal(err_string(data.msg), data.action_title);
            break;
        case 1:
            load_modal(success_string(data.msg), data.action_title);
            break;
        case 2:
            load_modal(info_string(data.msg), data.action_title);
            break;
        default:
            load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER"), "ERROR");      
    } 
  }else{
    load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER.."), "ERROR");
  }
}

function update_company_communications_result(data){
  $('#submit').prop("disabled", false);
  $(".form-progress").addClass("hide");

  if(data){
    switch(data.query_status) {
        case 0:
            load_modal(err_string(data.msg), data.action_title);
            break;
        case 1:
            load_modal(success_string(data.msg), data.action_title);
            break;
        case 2:
            load_modal(info_string(data.msg), data.action_title);
            break;
        default:
            load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER"), "ERROR");      
    } 
  }else{
    load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER.."), "ERROR");
  }
}

function update_company_financials_result(data){
  $('#submit').prop("disabled", false);
  $(".form-progress").addClass("hide");

  if(data){
    switch(data.query_status) {
        case 0:
            load_modal(err_string(data.msg), data.action_title);
            break;
        case 1:
            load_modal(success_string(data.msg), data.action_title);
            break;
        case 2:
            load_modal(info_string(data.msg), data.action_title);
            break;
        default:
            load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER"), "ERROR");      
    } 
  }else{
    load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER.."), "ERROR");
  }
}

function master_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  
  if(data){
    switch(data.query_status) {
        case 0:
            load_modal(err_string(data.msg), data.action_title);
            break;
        case 1:
            load_modal(success_string(data.msg), data.action_title);
            $("#"+data.actions).not(".ignore").trigger("reset");
            break;
        case 2:
            load_modal(info_string(data.msg), data.action_title);
            break;
        default:
            load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER"), "ERROR");      
    }
  }else{
    load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER"), "ERROR");      
  }
}