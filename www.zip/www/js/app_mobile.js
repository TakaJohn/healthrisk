var base_url            = "http://www.bouldercorp.com/hrm/"
var request_url         = base_url+"server_side/request.php";
var search_url          = base_url+"server_side/user_search.php";
var modal_url           = "modal.html";
var level_description   = ["", "super_administrator", "administrator"];

var user_id,
    user_role,
    user_profile,
    user_name, 
    user_surname,
    user_client_id, 
    user_client, 
    user_push_toke

var isPhoneGapReady     = false;
var isAndroid           = false;
var isBlackberry        = false;
var isIphone            = false;
var isWindows           = false;

var isConnected         = false;
var isHighSpeed         = false;
var internetInterval;
var connection_type;

var currentUrl;
var currentPage;

var device_platform, 
    device_model, 
    device_version, 
    device_uuid;

var pusher,
    pushNotification;

var watch_transaction_sms   = 0;
var ecocash_service_center  = "+263770010502";
var telecash_service_center = "xxxxxx";

var ecocash_sender          = "+263164";
var telecash_sender         = "xxxx";

var full_date               = new Date();
var year_date               = full_date.getFullYear();
var month_date              = full_date.getMonth();
var day_date                = full_date.getDate();

var tab_history = [];
var patient_list;

function onDeviceReady() {
  isPhoneGapReady   = true;
  //push notification
  
  //sms function
  /*sim card details
  window.plugins.sim.getSimInfo(
    function simDetails(){
      carrierName   = carrierName;
      countryCode   = countryCode;
      phoneNumber   = phoneNumber;
      simSerialNumber   = simSerialNumber;
      imei          = deviceId;
      imsi          = subscriberId;
    },     
    function simDetailsError(){
      console.log("Failed to get sim card details");
    }
  );*/

  device_platform   = device.platform.toLowerCase();  // device operating system e.g Android, Ios
  device_model      = device.model.toLowerCase();     //device model e.g Nexus One       returns "Passion
  device_version    = device.version.toLowerCase();   // device operating system version Froyo OS would return "2.2" 

  //networkDetection
  var networkState = navigator.connection.type;
    var states = {};
    states[Connection.UNKNOWN]  = 'Unknown connection';
    states[Connection.ETHERNET] = 'Ethernet connection';
    states[Connection.WIFI]     = 'WiFi connection';
    states[Connection.CELL_2G]  = 'Cell 2G connection';
    states[Connection.CELL_3G]  = 'Cell 3G connection';
    states[Connection.CELL_4G]  = 'Cell 4G connection';
    states[Connection.CELL]     = 'Cell generic connection';
    states[Connection.NONE]     = 'No network connection';
    if (states[networkState] !== 'No network connection' || states[networkState] == 'Unknown connection') {
      console.log("Connection State: "+states[networkState]);
    isConnected = true;
  }

  connection_type = states[networkState];
  
  document.addEventListener("online", onOnline, false);
  document.addEventListener("offline", onOffline, false);
  // attach events for pause and resume detection
  document.addEventListener("pause", onPause, false);
  document.addEventListener("resume", onResume, false);  
  
  //executeCallback 
  var pages = currentUrl.split("/"); // get the name of the current html page
  currentPage = pages[pages.length - 1].slice(0, pages[pages.length - 1].indexOf(".html"));
  console.log("CURRENT PAGE: "+currentPage);

  // capitalize the first letter and execute the function
  //currentPage = currentPage.charAt(0).toUpperCase() + currentPage.slice(1);

  //if ( typeof window['on' + currentPage + 'Load'] == 'function') {
  if ( typeof window[currentPage + '_load'] == 'function') {
    window[currentPage + '_load']();
  }
}

function onOnline() {
  isConnected = true;
}

function onOffline() {
  isConnected = false;
}

function onPause() {
  isPhoneGapReady = false;
  console.log("ON PAUSE");
}

function onResume() {
  console.log("ON RESUME");
  if (isPhoneGapReady == false) {
    init(currentUrl);
  }
}

function init(url) {
  if ( typeof url != 'string') {
    currentUrl = location.href;
  } else {
    currentUrl = url;
  }
  if (isPhoneGapReady) {
    onDeviceReady();
  } else {
    // Add an event listener for deviceready
    document.addEventListener("deviceready", onDeviceReady, false);
  }
}

jQuery(function($){  
  window.onload = init;
  user_username         = window.localStorage.getItem("username");
  user_role             = window.localStorage.getItem("role");
  user_name             = window.localStorage.getItem("name");
  user_surname          = window.localStorage.getItem("surname");
  user_id               = window.localStorage.getItem("id");
  user_client_id        = window.localStorage.getItem("client_id");
  user_client           = window.localStorage.getItem("client");

  if(user_id){
    $(".navbar-brand").html(user_client); 
    dashboard_page();
    user_side_menu();    
  }else{
    $('.load-content').load("modal.lockme.html", function(){
      $(".header").addClass("hide");
      $("#nav").addClass("hide");
    });
  } 

  //data-link function
  $(document).on('click', "a, data-link", function(e){
    var page = $(this).attr("data-link");
    
    if(page || page !== undefined){        
      var variables       = page.slice(page.indexOf('?') + 1).split('&');
      var num_variables   = variables.length;
      var url             = page.substr(0, page.indexOf('?'));
      
      if(url == "")
        actions = page+"_page";
      else
        actions = url+"_page";
      
      if ( typeof window[actions] == 'function') {
        if(num_variables > 0){
          window[actions](variables);
        }else{
          window[actions]();
        }
      }

      return false;
    }
  });

  $(document).on('click', "a, data-function", function(e){
    var func = $(this).attr("data-function");
    
    if(func || func !== undefined){        
      var variables       = func.slice(func.indexOf('?') + 1).split('&');
      var num_variables   = variables.length;
      var url             = func.substr(0, func.indexOf('?'));
      
      if(url == "")
        actions = func;
      else
        actions = func;
      
      if ( typeof window[actions] == 'function') {
        if(num_variables > 0){
          window[actions](variables);
        }else{
          window[actions]();
        }
      }

      return false;
    }
  });  

  //submit function
  $(document).on('submit', "form", function(e){
    var form    = "#"+$(this).attr("id");
    var title   = $(form+" #action_title").val();
    var action  = $(form+" #actions").val();

    $(form+" #submit").prop("disabled", true);   
    $(form+" .form-progress").removeClass("hide");
    
    //validate
    $(form+' .required').each(function(i){
               
      if($(this).val() == ''){
        var err_message = $(this).attr('data-error');
        var id_string = $(this).attr('id');
        $(form+" #submit").prop("disabled", false);   
        $(form+" .form-progress").addClass("hide");
        load_modal(info_string(err_message), title);
        return false;            
      } 
            
      if(i == $(form+' .required').length - 1){
        var post_data     = $(form).serialize();
        query_server(post_data, "POST", action+"_result");                
      }       
    });
      
    return false;
  });

  function query_server(post_data, method, result){
    if(method == "POST"){
      $.post(
        request_url+"?data="+btoa(post_data), 
          function(data, status) {
            $('#submit').prop("disabled", false);
            //$(".form-progress").addClass("hide");
            $(".form-progress").not(".hide", function(){
              $(this).addClass("hide");
            });
            console.log(data);

            switch(status){
              case "success":                
                try{
                  data = JSON.parse(data);
                  window[result](data);                   
                  console.log("success");
                }catch(err){
                  load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");                  
                  console.log(err);
                }
                break;
              case "error":
                load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
                
                console.log("error");
                break;
              case "timeout":
                load_modal(info_string("TIMEOUT ERROR. INTERNET CONNECTION SLOW. TRY AGAIN LATER."), "INFO");
                
                console.log("timeout");
                break;
              case "parsererror":
                load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
                
                console.log("parsererror");
                break;
            }
          }
      ).fail(function(data) {
        $('#submit').prop("disabled", false);
        //$(".form-progress").addClass("hide");
        $(".form-progress").not(".hide", function(){
          $(this).addClass("hide");
        });
        load_modal(err_string("PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION"); 
      });    
    }

    if(method == "GET"){
      $.get(
        request_url+"?data="+btoa(post_data), 
          function(data, status) {
            $('#submit').prop("disabled", false);
            //$(".form-progress").addClass("hide");
            $(".form-progress").not(".hide", function(){
              $(this).addClass("hide");
            });
            console.log(data);

            switch(status){
              case "success":                
                try{
                  data = JSON.parse(data);
                  window[result](data); 
                  
                  console.log("success");
                }catch(err){
                  load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
                  
                  console.log(err);
                }
                break;
              case "error":
                load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
                
                console.log("error");
                break;
              case "timeout":
                load_modal(info_string("TIMEOUT ERROR. INTERNET CONNECTION SLOW. TRY AGAIN LATER."), "INFO");
                
                console.log("timeout");
                break;
              case "parsererror":
                load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
                
                console.log("parsererror");
                break;
            }
          }
      ).fail(function(data) {
        $('#submit').prop("disabled", false);
        //$(".form-progress").addClass("hide");
        $(".form-progress").not(".hide", function(){
          $(this).addClass("hide");
        });
        load_modal(err_string("PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION"); 
      });     
    }
  }

  function user_side_menu(){
    switch(user_role) {
        case "1": //system administrator
            $(".nav-settings").removeClass("hide");
            $(".nav-claims").removeClass("hide");
            /*$(".nav-patients").removeClass("hide");*/
            $(".nav-submissions").removeClass("hide");
            $(".nav-wellnessday").removeClass("hide");
            $(".nav-service-providers").removeClass("hide");
            break;
        case "2": // administrator
            $(".nav-settings").removeClass("hide");
            $(".nav-claims").removeClass("hide");
            /*$(".nav-patients").removeClass("hide");*/
            $(".nav-submissions").removeClass("hide");
            $(".nav-wellnessday").removeClass("hide");
            $(".nav-service-providers").removeClass("hide");
            break;
    }
  }

  //PIC UPLOAD
  $(document).on('click', ".profile-pic", function(e){
    $('#pic-load').click();
    return false;
  });

  //LOGO UPLOAD
  $(document).on('click', ".logo-pic", function(e){
    $('#logo-load').click();
    return false;
  });

  //CV UPLOAD
  $(document).on('click', ".profile-file", function(e){
    $('#file-load').click();
    return false;
  });

  $(document).on('click', '[data-dismiss="modal"]',
    function(e) {
      close_modal();
    }
  );

});

//ajax uploader
function ajax_uploader(){
  $(function () {
      'use strict';
      $('#pic-load').fileupload({
          url: request_url+"?data="+btoa("actions=pic_upload"),
          dataType: 'json',
          acceptFileTypes: /(\.|\/)(gif|jpe?g|png)$/i,
          maxFileSize: 10000000, // 10 MB
          // Enable image resizing, except for Android and Opera,
          // which actually support image resizing, but fail to
          // send Blob objects via XHR requests:
          disableImageResize: /Android(?!.*Chrome)|Opera/ .test(window.navigator && navigator.userAgent),
          imageMaxWidth: 200,
          imageMaxHeight: 200,
          imageCrop: true,
          done: function (e, data) {
            console.log(data);
            if(data.result.files[0].error){
              $(".pic-upload-status").html(data.result.files[0].error).removeClass("hide");
              $('.pic-upload .progress').addClass("hide");
              $('.pic-upload .progress .progress-bar').css(
                'width', '1%'
              );
            }else{
              $("#profile").val(data.result.files[0].name);
              $(".profile-image").attr("src","profiles/"+data.result.files[0].name);
              $(".pic-upload-status").html('<span class="text-success"><i class="fa fa-thumbs-up"></i> 100%</span>').removeClass("hide");
              $('.pic-upload .progress').addClass("hide");
              $('.pic-upload .progress .progress-bar').css(
                'width', '1%'
              );
            }
          },
          progressall: function (e, data) {
              var progress = parseInt(data.loaded / data.total * 100, 10);
              $('.pic-upload .progress').removeClass("hide");
              $('.pic-upload .progress .progress-bar').css(
                  'width',
                  progress + '%'
              );
          }
      }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');

      $('#logo-load').fileupload({
          url: request_url+"?data="+btoa("actions=pic_upload"),
          dataType: 'json',
          //acceptFileTypes: /(\.|\/)(gif|jpe?g|png)$/i,
          //maxFileSize: 10000000, // 10 MB
          // Enable image resizing, except for Android and Opera,
          // which actually support image resizing, but fail to
          // send Blob objects via XHR requests:
          disableImageResize: /Android(?!.*Chrome)|Opera/ .test(window.navigator && navigator.userAgent),
          imageMaxWidth: 150 ,
          imageMaxHeight: 70,
          imageCrop: true,
          //autoUpload: false,
          done: function (e, data) {
            console.log(data);
            if(data.result.files[0].error){
              $(".logo-upload-status").html(data.result.files[0].error).removeClass("hide");
              $('.logo-upload .progress').addClass("hide");
              $('.logo-upload .progress .progress-bar').css(
                'width', '1%'
              );
            }else{
              $("#logo").val(data.result.files[0].name);
              $(".logo-image").attr("src","profiles/"+data.result.files[0].name);
              $(".logo-upload-status").html('<span class="text-success"><i class="fa fa-thumbs-up"></i> 100%</span>').removeClass("hide");
              $('.logo-upload .progress').addClass("hide");
              $('.logo-upload .progress .progress-bar').css(
                'width', '1%'
              );
            }
          },
          progressall: function (e, data) {
              var progress = parseInt(data.loaded / data.total * 100, 10);
              $('.logo-upload .progress').removeClass("hide");
              $('.logo-upload .progress .progress-bar').css(
                  'width',
                  progress + '%'
              );
          }
      }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
        
      $('#file-load').fileupload({
          url: "http://bouldercorp.com/hrm/server_side/request.php?data="+btoa("actions=file_upload"),
          dataType: 'json',
          done: function (e, data) {
            console.log(data);
            if(data.result.files[0].error){
              $(".file-upload-status").html(data.result.files[0].error).removeClass("hide");
              $('.file-upload .progress').addClass("hide");
              $('.file-upload .progress .progress-bar').css(
                'width', '1%'
              );
            }else{
              $("#file").val(data.result.files[0].name);
              $(".file-image").html('<i class="fa fa-folder-open-o fa-3x"></i> '+data.result.files[0].name);
              $(".file-upload-status").html('<span class="text-success"><i class="fa fa-thumbs-up"></i> 100%</span>').removeClass("hide");
              $('.file-upload .progress').addClass("hide");
              $('.file-upload .progress .progress-bar').css(
                'width', '1%'
              );
            }
          },
          progressall: function (e, data) {
              var progress = parseInt(data.loaded / data.total * 100, 10);
              $('.file-upload .progress').removeClass("hide");
              $('.file-upload .progress .progress-bar').css(
                  'width',
                  progress + '%'
              );
          }
      }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');

  });
}

//retract menu
function retract_menu(){
  if($(".mobile-menu-btn").hasClass('active')){
    $(".mobile-menu-btn").click();
  } 
}  

//terminate session
function terminate_session(){
  window.localStorage.removeItem("id");
  window.localStorage.removeItem("role");
  window.localStorage.removeItem("profile");
  window.localStorage.removeItem("name");
  window.localStorage.removeItem("surname");
  window.localStorage.removeItem("client");
  window.localStorage.removeItem("client_id");

  document.title = "SIGN IN";

  $('.load-content').load("modal.lockme.html", function(){
    $(".header").addClass("hide");
    $("#nav").addClass("hide");      
  });
}

document.addEventListener("backbutton", onBackKeyDown, false);

history.pushState(null, null, document.URL);
window.addEventListener('popstate', function () {
    history.pushState(null, null, document.URL);
});

$(window).on("popstate", function(e) {
  if (tab_history.length > 1) {
    var num_tabs          = tab_history.length;
    var previous          = tab_history[tab_history.length - 2];

    if(previous || previous !== undefined){ 
      var variables       = previous.slice(previous.indexOf('?') + 1).split('&');
      var num_variables   = variables.length;
      var url             = previous.substr(0, previous.indexOf('?'));

      if(url == "")
        actions = previous+"_page";
      else
        actions = url+"_page";
      
      if (typeof window[actions] == 'function') {
        tab_history.pop();
        tab_history.pop();
        //delete tab_history[previous];

        if(num_variables > 0){
          window[actions](variables);
        }else{
          window[actions]();
        }
      }
    }
  }
  e.preventDefault();
});

function onBackKeyDown(e) {
  if (tab_history.length > 1) {
    var num_tabs          = tab_history.length;
    var previous          = tab_history[tab_history.length - 2];

    if(previous || previous !== undefined){ 
      var variables       = previous.slice(previous.indexOf('?') + 1).split('&');
      var num_variables   = variables.length;
      var url             = previous.substr(0, previous.indexOf('?'));

      if(url == "")
        actions = previous+"_page";
      else
        actions = url+"_page";
      
      if (typeof window[actions] == 'function') {
        tab_history.pop();
        tab_history.pop();
        //delete tab_history[previous];

        if(num_variables > 0){
          window[actions](variables);
        }else{
          window[actions]();
        }
      }
    }
  }
  e.preventDefault();
}

function pageLoadingShow(){
  $(".se-pre-con").show();
}

function pageLoadingHide(){
  $(".se-pre-con").fadeOut("slow");
  if($(".mobile-menu-btn").hasClass('active')){
    $(".mobile-menu-btn").click();
  } 
}

function err_string(err){
  var string =  '<span class="fa-stack fa-2x pull-left m-r-sm">'+
                '<i class="fa fa-circle fa-stack-2x text-danger"></i>'+
                '<i class="fa fa-times fa-stack-1x text-white"></i>'+
                '</span>'+
                '<div class="clear"><p>'+err+'</p></div>';
  return string;
}

function success_string(err){
  var string =  '<span class="fa-stack fa-2x pull-left m-r-sm">'+
                '<i class="fa fa-circle fa-stack-2x text-success"></i>'+
                '<i class="fa fa-check fa-stack-1x text-white"></i>'+
                '</span>'+
                '<div class="clear"><p>'+err+'</p></div>';
  return string;
}

function info_string(err){
  var string =  '<span class="fa-stack fa-2x pull-left m-r-sm">'+
                '<i class="fa fa-circle fa-stack-2x text-info"></i>'+
                '<i class="fa fa-info fa-stack-1x text-white"></i>'+
                '</span>'+
                '<div class="clear"><p>'+err+'</p></div>';
  return string;
}

function message_string(err){
  var string =  '<span class="fa-stack fa-2x pull-left m-r-sm">'+
                '<i class="fa fa-circle fa-stack-2x text-primary"></i>'+
                '<i class="fa fa-envelope fa-stack-1x text-white"></i>'+
                '</span>'+
                '<div class="clear"><p>'+err+'</p></div>';
  return string;
}

function advert_string(client, msg, title, img){
  var string =  '<article class="media">'+
                '<span class="pull-left thumb-md"><img src="'+img+'"></span>'+
                '<div class="media-body">'+
                '<h4>'+title+'</h4>'+
                '<small class="block">'+client+'</small>'+
                '<small class="block m-t-sm">'+msg+'</small>'+
                '</div>'+
                '</article>';
  return string;
}

function window_redirect(location){
  window.location.replace(location+".html");
}

function load_modal(content, title){
  $('#ajaxModal').remove();

  var $remote  = modal_url;
  var $modal   = $('<div class="modal" id="ajaxModal"><div class="modal-body"></div></div>');

  $('body').append($modal);
  $modal.modal();
  $modal.load($remote, function(){
    $(".modal-title").html(title);
    $(".modal-body").html(content);

    $(".modal-body").on('click', "a, data-link", function(e){      
        var page = $(this).attr("data-link");

        if(page || page !== undefined){        
          var variables       = page.slice(page.indexOf('?') + 1).split('&');
          var num_variables   = variables.length;
          var url             = page.substr(0, page.indexOf('?'));
          
          if(url == "")
            actions = page+"_page";
          else
            actions = url+"_page";
          
          if ( typeof window[actions] == 'function') {
            if(num_variables > 0){
              window[actions](variables);
            }else{
              window[actions]();
            }
          }
        }    
        
        return false;
    });    
  });  
}

function close_modal(){
  $('#ajaxModal').remove();
  $('.modal-backdrop').remove();
  $("body").removeClass("modal-open");
}

function login_result(data){
  $('#submit').prop("disabled", false);
  $('.login .form-progress').addClass("hide");
  console.log(data);
  if(data){
    switch(data.query_status) {
        case 0:
            load_modal(err_string(data.msg), data.action_title);
            break;
        case 1:
            $(".header").removeClass("hide");
            $("#nav").removeClass("hide");

            window.localStorage.setItem("username", data.username);
            window.localStorage.setItem("role", data.role);
            window.localStorage.setItem("name", data.name);
            window.localStorage.setItem("surname", data.surname);
            window.localStorage.setItem("id", data.id);
            window.localStorage.setItem("client_id", data.client_id);
            window.localStorage.setItem("client", data.client);

            user_username         = data.username;
            user_role             = data.role;
            user_name             = data.name;
            user_surname          = data.surname;
            user_id               = data.id;
            user_client_id        = data.client_id;
            user_client           = data.client;
            
            //session_countdown();
            user_side_menu();            
            $('.load-content').load('template/dashboard.html', function(){ 
              tab_history[tab_history.length] = history;         
              $('.load-content').scrollTop(0);
              document.title = "Dashboard";

              if(data.medaids){
                var listData = '<option value=""> </option>';
                $.each(data.medaids, function(k, v) {
                  listData += '<option value="'+v.id+'">'+v.name+'</option>';
                });
                $("#medaid").html(listData);
              }

              
              $("#medaid").change(function(){
                var level_id = $(this).val();
                if($(this).val() == 1){
                  $(".names").removeClass('hide');
                  $(".meddetails").addClass('hide');
                }else{
                  $(".names").addClass('hide');
                  $(".meddetails").removeClass('hide');
                } 
              });

              $(document).on('click', ".profile-pic", function(e){
                $('#pic-load').click();
                return false;
              });

              $("#medaidnumber").autocomplete({
                 source: search_url,
                 minLength: 2
              });

              /*$("#medaidnumber").autocomplete({
                source: search_url,
                minLength: 2,
                select: function(event, ui) {
                    var url = ui.item.id;
                    if(url != '#') {
                        location.href = '/blog/' + url;
                    }
                },
         
                html: true, // optional (jquery.ui.autocomplete.html.js required)
         
              // optional (if other layers overlap autocomplete list)
                open: function(event, ui) {
                    $(".ui-autocomplete").css("z-index", 1000);
                }
            });*/

            });
            break;
        case 2:
            load_modal(info_string(data.msg), data.action_title);
            break;      
    }
  }else{
    load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");      
  }
}

function show_claims(data){
  memberno       = $("#medaidnumber").val();
  depno          = $("#suffix").val();

  if(memberno && depno){
    pageLoadingShow();
    post_data       = "actions=patient_claims&user_id="+user_id+"&memberno="+memberno+"&depno="+depno;
    $.post(request_url+"?data="+btoa(post_data), function(data) {
      console.log(data);
      pageLoadingHide();      
      try{
        var data = $.parseJSON(data);
        switch(data.query_status) {
            case 0:
                load_modal(err_string(data.msg), data.action_title);
                break;
            case 1:
                if(data.details){
                  listData      = "";
                  $.each(data.details, function(k, v) {
                    listData += '<tr>'+
                                '<td>'+v.name+'</td>'+
                                '<td>'+v.memberno+'</td>'+
                                '<td>'+v.claimno+'</td>'+
                                '<td>'+v.amount+'</td>'+
                                '<td>'+v.description+'</td>'+
                                '<td>'+v.date+'</td>'+
                                '<td>'+v.view+'</td>'+
                                '</tr>';
                  });
                  $(".claims-grid").html(listData);
                  $(".claims-table").DataTable({
                    "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
                    "sPaginationType": "full_numbers"
                  });
                  $(".view-claims").removeClass("hide");
                  $(".view_health_data").addClass("hide");
                }else{
                  load_modal(info_string("This patient has no recent claims"), data.action_title);
                }
                break;
            case 2:
                load_modal(info_string(data.msg), data.action_title);
                break;
            default:
                load_modal(err_string("THERE WAS AN ERROR ACCESSING PATIENT CLAIMS. TRY AGAIN LATER"), "ERROR");
        }

      }catch(err){
        load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
      }
    }).fail(function(data) {
      pageLoadingHide();
      
      load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
    });
  }else{
    load_modal(err_string("ERROR: PLEASE FILL IN BOTH MEMBER # AND SUFFIX"), "ERROR");
  }
}

function show_health_data(data){
  memberno       = $("#medaidnumber").val();
  depno          = $("#suffix").val();

  if(memberno && depno){
    pageLoadingShow();
    post_data       = "actions=patient_data&user_id="+user_id+"&memberno="+memberno+"&depno="+depno;
    $.post(request_url+"?data="+btoa(post_data), function(data) {
      pageLoadingHide();      
      try{
        var data = $.parseJSON(data);
        switch(data.query_status) {
            case 0:
                load_modal(err_string(data.msg), data.action_title);
                break;
            case 1:
                if(data.details){
                  listData      = "";
                  x             = 0;
                  $.each(data.details, function(k, v) {
                    listData += '<div class="panel panel-default">'+
                                '<div class="panel-heading">'+

                                '<div class="row">'+
                                '<div class="col-sm-6 col-xs-6">'+
                                '<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse'+x+'">'+v.date+'</a>'+                                
                                '</div>'+
                                '<div class="col-sm-6 col-xs-6">'+v.view+'</div>'+
                                '</div>'+

                                '</div>'+

                                '<div id="collapse'+x+'" class="panel-collapse in">'+
                                '<div class="panel-body text-sm">'+

                                  '<div class="row">'+
                                  '<div class="col-sm-4 col-xs-4">Height: '+v.height+'</div>'+
                                  '<div class="col-sm-4 col-xs-4">Weight:'+v.weight+'</div>'+
                                  '<div class="col-sm-4 col-xs-4">B.M.I: '+v.bmi+'</div>'+
                                  '</div>'+

                                  '<div class="row">'+
                                  '<div class="col-sm-4 col-xs-4">Cholestroral:'+v.cholestroral+'</div>'+
                                  '<div class="col-sm-4 col-xs-4">Blood Sugar:'+v.bloodsugar+'</div>'+
                                  '</div>'+

                                  '<div class="row">'+
                                  '<div class="col-sm-4 col-xs-4">B.P:'+v.bp+'</div>'+
                                  '<div class="col-sm-4 col-xs-4">Pulse Rate:'+v.pulserate+'</div>'+
                                  '</div>'+

                                  '<div class="row">'+
                                  '<div class="col-sm-4 col-xs-4">H.I.V:'+v.hiv+'</div>'+
                                  '<div class="col-sm-4 col-xs-4">Pathology:'+v.pathology+'</div>'+
                                  '</div>'+

                                  '<div class="row">'+
                                  '<div class="col-sm-4 col-xs-4">Notes:'+v.notes+'</div>'+
                                  '</div>'+

                                '</div>'+
                                '</div>'+

                                '</div>';
                    x++;
                  });

                  if(listData){
                    $(".details-accordian").html(listData);                    
                    $(".view_health_data").removeClass("hide");
                    $(".view-claims").addClass("hide");
                  }else{
                    load_modal(info_string("No recent health data collected"), data.action_title);
                  }
                }else{
                  load_modal(info_string("No recent health data collected"), data.action_title);
                }
                break;
            case 2:
                load_modal(info_string(data.msg), data.action_title);
                break;
            default:
                load_modal(err_string("THERE WAS AN ERROR ACCESSING PATIENT CLAIMS. TRY AGAIN LATER"), "ERROR");
        }

      }catch(err){
        load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
      }
    }).fail(function(data) {
      pageLoadingHide();
      
      load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
    });
  }else{
    load_modal(err_string("ERROR: PLEASE FILL IN BOTH MEMBER # AND SUFFIX"), "ERROR");
  }
}

function show_collect_data(data){
  $(".collect-medical-data").removeClass("hide");
  $(".view_health_data").addClass("hide");
  $(".view-claims").addClass("hide");
}

function dashboard_page(){
  pageLoadingShow();
  history_          = "dashboard";
  post_data         = "actions=dashboard&user_id="+user_id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();
    try{
      var data = $.parseJSON(data); 
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), "ERROR");
              break;
          case 1:
              $('.load-content').load('template/dashboard.html', function(){          
                $('.load-content').scrollTop(0);
                document.title = "Dashboard";
                tab_history[tab_history.length] = history_;
                

                if(data.medaids){
                  var listData = '<option value=""> </option>';
                  $.each(data.medaids, function(k, v) {
                    listData += '<option value="'+v.id+'">'+v.name+'</option>';
                  });
                  $("#medaid").html(listData);
                }

                if(data.wellnessdays){
                  var listData = '<option value=""> </option>';
                  $.each(data.wellnessdays, function(k, v) {
                    listData += '<option value="'+v.id+'">'+v.name+'</option>';
                  });
                  $("#wellnessday").html(listData);
                }

                $("#medaid").change(function(){
                  var level_id = $(this).val();
                  console.log("medaid number: "+level_id);

                  switch($(this).val()){
                    case "1":
                      $(".patient-names").removeClass('hide');
                      $(".meddetails").addClass("hide");
                      $(".next-health-action").addClass("hide");

                      $(".view-claims").addClass("hide");
                      $(".claims-grid").html("");

                      $(".collect-medical-data").removeClass("hide");
                      $(".collect-medical-data").children().find("input, select").each(function(){
                        $(this).val('');
                      });
                      break;
                    default:
                      $(".patient-names").addClass('hide');
                      $(".meddetails").removeClass("hide");
                      $(".next-health-action").removeClass("hide");
                      $(".collect-medical-data").addClass("hide");
                      $(".collect-medical-data").children().find("input, select").each(function(){
                        $(this).val('');
                      });
                      break;
                  }
                });

                $("#medaidnumber").autocomplete({
                   source: search_url,
                   minLength: 2
                });

                $("#height").change(function(){
                  var height = $(this).val();
                  console.log(height);
                  var weight = $("#weight").val();
                  if(height && weight){
                    var bmi   = weight/((height/100) * (height/100));
                    $("#bmi").val(bmi.toFixed(2));
                  }
                });

                $("#weight").change(function(){
                  var weight = $(this).val();
                  console.log(weight);
                  var height = $("#height").val();
                  if(height && weight){
                    var bmi   = weight/((height/100) * (height/100));
                    $("#bmi").val(bmi.toFixed(2));
                  }
                });
              });
              break;
          case 2:
              load_modal(info_string(data.msg), "ERROR");
              break;
      }
    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function profile_page(data){
  history_          = "profile";
  post_data         = "actions=profile_details&user_id="+user_id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    try{
      var data = $.parseJSON(data);
      retract_menu();

      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              $('.load-content').load('template/profile.html', function(){
                tab_history[tab_history.length] = history_;
                $('.load-content').scrollTop(0);
                document.title = "MY DETAILS";

                //users details
                if(data.details){                  
                  $(".flex-heading").html(data.details.title+" "+data.details.name+" "+data.details.surname+" Details");
                  
                  $("input[name='user_id']").each(function(){ $(this).val(user_id) });

                  $("select[name='title']").val(data.details.title);
                  $("input[name='name']").val(data.details.name);
                  $("input[name='surname']").val(data.details.surname);

                  $("input[name='nationalid']").val(data.details.nationalid);
                  $("input[name='birthdate']").val(data.details.birthdate);

                  $("input[name='address']").val(data.details.address);
                  $("input[name='area']").val(data.details.area);
                  $("input[name='city']").val(data.details.city);
                  $("input[name='mobile']").val(data.details.mobile);
                  $("input[name='email']").val(data.details.email);
                  $("input[name='username']").val(data.details.username);
                  $("select[name='status']").val(data.details.status);
                }
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESSING DETAILS. PLEASE TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("There was na error processing your request. Please try again later"), "ERROR");
      retract_menu();
    }
  }).fail(function(data) {
    pageLoadingHide();
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function update_profile_result(data){
  $('#submit').prop("disabled", false);
  $(".form-progress").addClass("hide");

  if(data){
    switch(data.query_status) {
        case 0:
            load_modal(err_string(data.msg), data.action_title);
            break;
        case 1:
            load_modal(success_string(data.msg), data.action_title);
            break;
        case 2:
            load_modal(info_string(data.msg), data.action_title);
            break;
        default:
            break;      
    }
  }else{
    load_modal(err_string("There was na error processing your request. Please try again later"), "ERROR");   
  }
}

function logout_page(){
  //terminate_pusher();
  terminate_session();
}

function zumba_register_page(){
  pageLoadingShow();
  post_data         = "actions=zumba_variables&user_id="+user_id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              pageLoadingHide();
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              $('.load-content').load('template/zumba_register.html', function(){
                pageLoadingHide();
                tab_history[tab_history.length] = "dashboard";
                $('.load-content').scrollTop(0);
                document.title = "ZUMBA ATTENDANCE";
                $('.datepicker-input').datepicker();
                if(data.venues){
                  listData = "<option value=''>SELECT VENUE</option>";

                  $.each(data.venues, function(k, v) {
                    listData += '<option value="'+v.id+'">'+v.name+'</option>';
                  });

                  $("#venue").html(listData);
                }

                if(data.medaids){
                  listData = "<option value=''>SELECT MEDICAL AID</option>";

                  $.each(data.medaids, function(k, v) {
                    listData += '<option value="'+v.id+'">'+v.name+'</option>';
                  });

                  $("#insurer").html(listData);
                }

                //auto-complete search
                var term = $("#searchterm").val();
                $(document).on('focus', '#searchterm', function(e){
                  $(this).autocomplete({
                    minLength: 2,
                    source: function(request, response){
                      $.getJSON(
                        request_url, 
                        {user_id: user_id, term: $("#searchterm").val(), data: btoa("actions=user_search")},
                        response);
                    },
                    select: function(event, ui){
                      var label       = ui.item.label;
                      var value       = ui.item.value;
                      var id          = ui.item.id;
                      var memberno     = ui.item.memberno;

                      $("input[name='memberno']").val(ui.item.memberno);
                      //$("input[name='customer_name']").val(ui.item.value);
                      //$("input[name='account']").val(ui.item.account);
                    }
                  });
                });
              });
              break;
          case 2:
              pageLoadingHide();
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              pageLoadingHide();
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
      //console.log(err);
    }
  }).fail(function(data) {
    pageLoadingHide();
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function zumba_register_result(data){
  $('#submit').prop("disabled", false);
  $(".form-progress").addClass("hide");

  if(data){
    switch(data.query_status) {
        case 0:
            load_modal(err_string(data.msg), data.action_title);
            break;
        case 1:
            load_modal(success_string(data.msg), data.action_title);
            $("#"+data.actions).not(".ignore").trigger("reset");
            break;
        case 2:
            load_modal(info_string(data.msg), data.action_title);
            break;
        default:
            break;      
    }
  }else{
    load_modal(err_string("There was na error processing your request. Please try again later"), "ERROR");   
  }
}

function zumba_report_page(data){
  history_          = "sales";
  post_data         = "actions=zumba_report&user_id="+user_id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    try{
      var data = $.parseJSON(data);
      retract_menu();

      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              $('.load-content').load('template/zumba_report.html', function(){
                tab_history[tab_history.length] = history_;
                $('.load-content').scrollTop(0);
                document.title = "ZUMBA REPORT "+data.fromdate+" - "+data.todate;
                $('.datepicker-input').datepicker();
                $("input[name='user_id']").val(user_id);
                $("input[name='fromdate']").val(data.fromdate);
                $("input[name='todate']").val(data.todate);

                $(".flex-heading").html("ZUMBA REPORT "+data.fromdate+" - "+data.todate);

                var num_dep = 0;
                var num_principals = 0;

                if(data.attendance){
                  var listData = "";

                  $.each(data.attendance, function(k, v) {
                  console.log(v.membername);
                    listData += '<tr>'+
                                '<td>'+v.membername+'</td>'+
                                '<td>'+v.insurer+'</td>'+
                                '<td>'+v.venue+'</td>'+
                                '<td>'+v.nodep+'</td>'+
                                '<td>'+v.date+'</td>'+
                                '<td><a class="btn btn-sm" data-link="zumba_delete?id='+v.id+'" href="#"><i class="fa fa-ban m-r-xs"></i>Delete</a></td>'+
                                '</tr>';

                    num_dep = num_dep + parseInt(v.nodep);
                    num_principals++;
                  });

                  $("#attendance-grid").html(listData);
                  $("#attendance-table").DataTable({
                    "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
                    "sPaginationType": "full_numbers"
                  });
                }

                //stats panel
                $("#stat-num_principals").html(num_principals);
                $("#stat-num-dep").html(num_dep);
                console.log(num_principals);

                //attendance graph
                $("#attendance-graph .panel-heading").html("ATTENDANCE ("+data.fromdate+" "+data.todate+")");
                if(data.attendance_graph){
                  load_graph("#attendance-graph #graph-data", data.attendance_graph);
                }

              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESSING DETAILS. PLEASE TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("There was na error processing your request. Please try again later"), "ERROR");
      retract_menu();
    }
  }).fail(function(data) {
    pageLoadingHide();
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function zumba_report_result(data){
  $('#submit').prop("disabled", false);
  $(".form-progress").addClass("hide");

  if(data){
    switch(data.query_status) {
        case 0:
            load_modal(err_string(data.msg), data.action_title);
            break;
        case 1:            
            $('.load-content').scrollTop(0);
            document.title = "ZUMBA REPORT "+data.fromdate+" - "+data.todate;

            $("input[name='user_id']").val(user_id);
            $("input[name='fromdate']").val(data.fromdate);
            $("input[name='todate']").val(data.todate);

            $(".flex-heading").html("ZUMBA REPORT "+data.fromdate+" - "+data.todate);

            var num_dep = 0;
            var num_principals = 0;

            if(data.attendance){
              var listData = "";

              $.each(data.attendance, function(k, v) {
                listData += '<tr>'+
                            '<td>'+v.membername+'</td>'+
                            '<td>'+v.insurer+'</td>'+
                            '<td>'+v.venue+'</td>'+
                            '<td>'+v.nodep+'</td>'+
                            '<td>'+v.date+'</td>'+
                            '<td><a class="btn btn-sm" data-link="zumba_delete?id='+v.id+'" href="#"><i class="fa fa-ban m-r-xs"></i>Delete</a></td>'+
                            '</tr>';

                num_dep = num_dep + parseInt(v.nodep);
                num_principals++;
              });
              $("#attendance-table").dataTable().fnDestroy();
              $("#attendance-grid").html(listData);
              $("#attendance-table").DataTable({
                "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
                "sPaginationType": "full_numbers"
              });
            }

            //stats panel
            $("#stat-num-principals").html(num_principals);
            $("#stat-num-principals").html(num_dep);

            //attendance graph
            $("#attendance-graph .panel-heading").html("ATTENDANCE ("+data.fromdate+" "+data.todate+")");
            if(data.attendance_graph){
              $("#attendance-graph").removeClass("hide");
              load_graph("#attendance-graph #graph-data", data.attendance_graph);
            }else{
              $("#attendance-graph").addClass("hide");
            }
            break;
        case 2:
            load_modal(info_string(data.msg), data.action_title);
            break;
        default:
            break;      
    }
  }else{
    load_modal(err_string("There was na error processing your request. Please try again later"), "ERROR");   
  }
}

function zumba_venue_create_page(){
  pageLoadingShow();
  history_          = "zumba_venue_create";
  $('.load-content').load("template/zumba_venue_create.html", function(){ 
    tab_history[tab_history.length] = history_;
    pageLoadingHide();           
  });
}

function zumba_venue_create_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  if(data){
    switch(data.query_status){
      case 0:
        load_modal(err_string(data.msg), "CREATE VENUE");
        break;
      case 1:
        load_modal(success_string(data.msg), "CREATE VENUE"); 
        break;
      case 2: 
        load_modal(err_string(data.msg), "CREATE VENUE");
        break;
    }
  }else{
    load_modal(err_string("ERROR PROCESSING YOUR REQUEST. PLEASE TRY LATER."), "PERMISSIONS");
  }      
}

function collect_patient_data_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");

  if(data){
    console.log("RESULT: "+data.query_status);
    switch(data.query_status) {
        case 0:
            load_modal(err_string(data.msg), data.action_title);
            console.log("wrong");
            break;
        case 1:
            load_modal(success_string(data.msg), data.action_title);
            $("#"+data.actions).not(".ignore").trigger("reset");
            console.log("correct");
            break;
        case 2:
            load_modal(info_string(data.msg), data.action_title);
            console.log("wrong");
            break;
        default:
            break;      
    }
  }else{
    load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER 123."), "ERROR"); 
    console.log("no data error");     
  }
}

function zumba_delete_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "id"){
      var id = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  $(".delete-progress").removeClass("hide");

  var r = confirm("Are you sure you want to delete this entry?");

  if (r == true) {
      post_data         = "actions=zumba_delete&user_id="+user_id+"&id="+id;
      $.post(request_url+"?data="+btoa(post_data), function(data) {
        $(".delete-progress").addClass("hide");

        try{
          var data = $.parseJSON(data);

          switch(data.query_status) {
              case 0:
                  load_modal(err_string(data.msg), "DELETE ENTRY");
                  break;
              case 1:
                  load_modal(success_string(data.msg), "DELETE ENTRY");
                  zumba_report_page();
                  break;
              case 2:
                  load_modal(info_string(data.msg), "DELETE ENTRY");
                  break;
              default:
                  load_modal(err_string("THERE WAS AN ERROR TRYING TO DELETE THIS ENTRY. PLEASE TRY AGAIN LATER"), "ERROR");
          }

        }catch(err){
          load_modal(err_string("THERE WAS AN ERROR TRYING TO DELETE THIS ENTRY. PLEASE TRY AGAIN LATER"), "ERROR");
          retract_menu();
        }
      }).fail(function(data) {
        pageLoadingHide();
        load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
      });
  } else {
      $(".delete-progress").addClass("hide");
  }
}

function data_submissions_page(){
  pageLoadingShow();
  history_          = "data_submissions";
  post_data         = "actions=data_submissions&user_id="+user_id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading;
              $('.load-content').scrollTop(0);              
              $('.load-content').load("template/data_submissions.html", function(){ 
                $('.flex-heading').html(data.heading);
                $('.datepicker-input').datepicker();
                $("input[name='fromdate']").val(data.fromdate);
                $("input[name='todate']").val(data.todate);
                tab_history[tab_history.length] = history_;
                
                if(data.details){
                  listData      = "";
                  $.each(data.details, function(k, v) {
                    listData += '<tr>'+
                                '<td>'+v.date+'</td>'+
                                '<td>'+v.name+'</td>'+
                                '<td>'+v.memberno+'</td>'+
                                '<td>'+v.suffix+'</td>'+
                                '<td>'+v.view+'</td>'+
                                '</tr>';
                  });
                  $(".submissions-grid").html(listData);
                  $(".submissions-table").DataTable({
                    "order":[[0, "asc"]],
                    "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
                    "sPaginationType": "full_numbers"
                  });
                }           
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function data_submissions_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  if (data){
    switch(data.query_status){
      case 0:
        load_modal(err_string(data.msg), "ERROR");
        break;
      case 1:
        document.title = data.heading;
        $('.flex-heading').html(data.heading);
        $("input[name='fromdate']").val(data.fromdate);
        $("input[name='todate']").val(data.todate);
        if(data.details){
          listData      = "";
          $.each(data.details, function(k, v) {
            listData += '<tr>'+
                        '<td>'+v.name+'</td>'+
                        '<td>'+v.memberno+'</td>'+
                        '<td>'+v.suffix+'</td>'+
                        '<td>'+v.view+'</td>'+
                        '</tr>';
          });
          $(".submissions-grid").html(listData);
          $(".submissions-table").DataTable({
            "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
            "sPaginationType": "full_numbers"
          });
        }  
        break;
      case 2: 
        break;
    }
  }else{
    load_modal(err_string("ERROR PROCESSING YOUR REQUEST. PLEASE TRY LATER."), "PERMISSIONS");
  }      
}

function delete_data_submission_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "id"){
      var id = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  $(".delete-progress").removeClass("hide");

  var r = confirm("Are you sure you want to delete this entry?");
  if (r == true) {
      post_data         = "actions=delete_data_submission&user_id="+user_id+"&id="+id;
      $.post(request_url+"?data="+btoa(post_data), function(data) {
        $(".delete-progress").addClass("hide");

        try{
          var data = $.parseJSON(data);

          switch(data.query_status) {
              case 0:
                  load_modal(err_string(data.msg), "DELETE ENTRY");
                  break;
              case 1:
                  load_modal(success_string(data.msg), "DELETE ENTRY");
                  sales_page();
                  break;
              case 2:
                  load_modal(info_string(data.msg), "DELETE ENTRY");
                  break;
              default:
                  load_modal(err_string("THERE WAS AN ERROR TRYING TO DELETE THIS ENTRY. PLEASE TRY AGAIN LATER"), "ERROR");
          }

        }catch(err){
          load_modal(err_string("THERE WAS AN ERROR TRYING TO DELETE THIS ENTRY. PLEASE TRY AGAIN LATER"), "ERROR");
          retract_menu();
        }
      }).fail(function(data) {
        pageLoadingHide();
        load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
      });
  } else {
      $(".delete-progress").addClass("hide");
  }
}

function submission_details_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "id"){
      var id = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  pageLoadingShow();
  history_          = "submission_details?id="+id
  post_data         = "actions=submission_details&user_id="+user_id+"&id="+id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();

    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              $('.load-content').load('template/submission_details.html', function(){
                tab_history[tab_history.length] = history_;
                $('.load-content').scrollTop(0);
                document.title = data.heading;
                $(".flex-heading").html(data.heading);

                if(data.medaids){
                  var listData = '<option value=""> </option>';
                  $.each(data.medaids, function(k, v) {
                    listData += '<option value="'+v.id+'">'+v.name+'</option>';
                  });
                  $("#medaid").html(listData);
                }

                if(data.wellnessdays){
                  var listData = '<option value=""> </option>';
                  $.each(data.wellnessdays, function(k, v) {
                    listData += '<option value="'+v.id+'">'+v.name+'</option>';
                  });
                  $("#wellnessday").html(listData);
                }

                //users details
                if(data.details){
                  if(data.details.suffix && data.details.memberno)
                  $(".history").attr("data-link", "patient_data?memberno="+data.details.memberno+"&depno="+data.details.suffix).removeClass("hide");

                  $("input[name='id']").val(data.details.id);
                  $("select[name='medaid']").val(data.details.medicalaid);
                  $("input[name='name']").val(data.details.name);
                  $("input[name='surname']").val(data.details.surname);
                  $("input[name='medaidnumber']").val(data.details.memberno);
                  $("input[name='suffix']").val(data.details.suffix);
                  $("input[name='height']").val(data.details.height);
                  $("input[name='weight']").val(data.details.weight);
                  $("input[name='bmi']").val(data.details.bmi);
                  $("input[name='cholestroral']").val(data.details.cholestroral);
                  $("input[name='bloodsugar']").val(data.details.bloodsugar);
                  $("select[name='wellnessday']").val(data.details.wellnessday);
                  $("input[name='mobile']").val(data.details.mobile);
                  $("input[name='email']").val(data.details.email);
                  $("select[name='hiv']").val(data.details.hiv);
                  $("input[name='bp']").val(data.details.bp);
                  $("input[name='pulserate']").val(data.details.pulserate);
                  $("select[name='pathology']").val(data.details.pathology);
                  $("select[name='risk']").val(data.details.risk);
                  $("textarea[name='notes']").val(data.details.notes);
                }

                if(data.details.name && data.details.surname){
                  $(".patient-names").removeClass("hide");
                }

                if(data.details.memberno && data.details.suffix){
                  $(".meddetails").removeClass("hide");
                }

                $("#height").change(function(){
                  var height = $(this).val();
                  console.log(height);
                  var weight = $("#weight").val();
                  if(height && weight){
                    var bmi   = weight/((height/100) * (height/100));
                    $("#bmi").val(bmi.toFixed(2));
                  }
                });

                $("#weight").change(function(){
                  var weight = $(this).val();
                  console.log(weight);
                  var height = $("#height").val();
                  if(height && weight){
                    var bmi   = weight/((height/100) * (height/100));
                    $("#bmi").val(bmi.toFixed(2));
                  }
                });
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }
    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
      $(".navbar-brand").html(user_client);
      
    }
  }).fail(function(data) {
    pageLoadingHide();
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function update_patient_data_result(data){
  $('#submit').prop("disabled", false);
  $(".form-progress").addClass("hide");

  if(data){
    switch(data.query_status) {
        case 0:
            load_modal(err_string(data.msg), data.action_title);
            break;
        case 1:
            load_modal(success_string(data.msg), data.action_title);
            break;
        case 2:
            load_modal(info_string(data.msg), data.action_title);
            break;
        default:
            load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER"), "ERROR");      
    } 
  }else{
    load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER.."), "ERROR");
  }
}

function patient_data_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "memberno"){
      var memberno = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    } 
    if(data[i].substr(0, data[i].indexOf("=")) == "depno"){
      var depno = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  pageLoadingShow();
  history_          = "patient_data?memberno="+memberno+"&depno="+depno;
  post_data         = "actions=patient_data&user_id="+user_id+"&memberno="+memberno+"&depno="+depno;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading;
              $('.load-content').scrollTop(0);              
              $('.load-content').load("template/patient_data.html", function(){ 
                tab_history[tab_history.length] = history_;
                $('.flex-heading').html(data.heading);
                $('.datepicker-input').datepicker();

                if(data.details){
                  listData      = "";
                  x             = 0;
                  $.each(data.details, function(k, v) {
                    listData += '<div class="panel panel-default">'+
                                '<div class="panel-heading">'+

                                '<div class="row">'+
                                '<div class="col-sm-6 col-xs-6">'+
                                '<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapse'+x+'">'+v.date+'</a>'+                                
                                '</div>'+
                                '<div class="col-sm-6 col-xs-6">'+v.view+'</div>'+
                                '</div>'+

                                '</div>'+

                                '<div id="collapse'+x+'" class="panel-collapse in">'+
                                '<div class="panel-body text-sm">'+

                                  '<div class="row">'+
                                  '<div class="col-sm-4 col-xs-4">Height: '+v.height+'</div>'+
                                  '<div class="col-sm-4 col-xs-4">Weight:'+v.weight+'</div>'+
                                  '<div class="col-sm-4 col-xs-4">B.M.I: '+v.bmi+'</div>'+
                                  '</div>'+

                                  '<div class="row">'+
                                  '<div class="col-sm-4 col-xs-4">Cholestroral:'+v.cholestroral+'</div>'+
                                  '<div class="col-sm-4 col-xs-4">Blood Sugar:'+v.bloodsugar+'</div>'+
                                  '</div>'+

                                  '<div class="row">'+
                                  '<div class="col-sm-4 col-xs-4">B.P:'+v.bp+'</div>'+
                                  '<div class="col-sm-4 col-xs-4">Pulse Rate:'+v.pulserate+'</div>'+
                                  '</div>'+

                                  '<div class="row">'+
                                  '<div class="col-sm-4 col-xs-4">H.I.V:'+v.hiv+'</div>'+
                                  '<div class="col-sm-4 col-xs-4">Pathology:'+v.pathology+'</div>'+
                                  '</div>'+

                                  '<div class="row">'+
                                  '<div class="col-sm-4 col-xs-4">Notes:'+v.notes+'</div>'+
                                  '</div>'+

                                '</div>'+
                                '</div>'+

                                '</div>';
                    x++;
                  });
                  $(".details-accordian").html(listData);
                }           
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function patient_data_result(){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  if (data){
    switch(data.query_status){
      case 0:
        load_modal(err_string(data.msg), "ERROR");
        break;
      case 1:
        document.title = data.heading;
        $('.flex-heading').html(data.heading);

        if(data.details){
          listData      = "";
          $.each(data.details, function(k, v) {
            listData += '<tr>'+
                        '<td>'+v.name+'</td>'+
                        '<td>'+v.memberno+'</td>'+
                        '<td>'+v.claimno+'</td>'+
                        '<td>'+v.amount+'</td>'+
                        '<td>'+v.date+'</td>'+
                        '<td>'+v.view+'</td>'+
                        '</tr>';
          });
          $(".claims-grid").html(listData);
          $(".claims-table").DataTable({
            "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
            "sPaginationType": "full_numbers"
          });
        }    
        break;
      case 2: 
        break;
    }
  }else{
    load_modal(err_string("ERROR PROCESSING YOUR REQUEST. PLEASE TRY LATER."), "PERMISSIONS");
  } 
}

function patient_group_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "memberno"){
      var memberno = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }       
  }

  pageLoadingShow();
  history_          = "patient_group?memberno="+memberno;
  post_data         = "actions=patient_group&user_id="+user_id+"&memberno="+memberno;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading;
              $('.load-content').scrollTop(0);              
              $('.load-content').load("template/patient_group.html", function(){ 
                tab_history[tab_history.length] = history_;
                $('.flex-heading').html(data.heading);

                if(data.details){
                  listData      = "";
                  $.each(data.details, function(k, v) {
                    listData += '<tr>'+
                                '<td>'+v.name+'</td>'+
                                '<td>'+v.memberno+'</td>'+
                                '<td>'+v.suffix+'</td>'+
                                '<td>'+v.view+'</td>'+
                                '</tr>';
                  });
                  $(".details-grid").html(listData);
                }           
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

//claims

function claims_page(){
  pageLoadingShow();
  history_           = "claims";
  post_data         = "actions=claims&user_id="+user_id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading;
              $('.load-content').scrollTop(0);              
              $('.load-content').load("template/claims.html", function(){ 
                tab_history[tab_history.length] = history_;
                
                $('.flex-heading').html(data.heading);
                $('.datepicker-input').datepicker();

                $("input[name='fromdate']").val(data.fromdate);
                $("input[name='todate']").val(data.todate);

                if(data.details){
                  listData      = "";
                  $.each(data.details, function(k, v) {
                    listData += '<tr>'+
                                '<td>'+v.name+'</td>'+
                                '<td>'+v.memberno+'</td>'+
                                '<td>'+v.claimno+'</td>'+
                                '<td>'+v.amount+'</td>'+
                                '<td>'+v.date+'</td>'+
                                '<td>'+v.view+'</td>'+
                                '</tr>';
                  });
                  $(".claims-grid").html(listData);
                  $(".claims-table").DataTable({
                    "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
                    "sPaginationType": "full_numbers"
                  });
                }           
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function claims_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  if (data){
    switch(data.query_status){
      case 0:
        load_modal(err_string(data.msg), "ERROR");
        break;
      case 1:
        document.title = data.heading;
        $('.flex-heading').html(data.heading);

        if(data.details){
          listData      = "";
          $.each(data.details, function(k, v) {
            listData += '<tr>'+
                        '<td>'+v.name+'</td>'+
                        '<td>'+v.memberno+'</td>'+
                        '<td>'+v.claimno+'</td>'+
                        '<td>'+v.amount+'</td>'+
                        '<td>'+v.date+'</td>'+
                        '<td>'+v.view+'</td>'+
                        '</tr>';
          });
          $(".claims-grid").html(listData);
          $(".claims-table").DataTable({
            "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
            "sPaginationType": "full_numbers"
          });
        }    
        break;
      case 2: 
        break;
    }
  }else{
    load_modal(err_string("ERROR PROCESSING YOUR REQUEST. PLEASE TRY LATER."), "PERMISSIONS");
  } 
}

function patient_claims_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "memberno"){
      var memberno = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    } 
    if(data[i].substr(0, data[i].indexOf("=")) == "depno"){
      var depno = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  pageLoadingShow();
  history_          = "patient_claims?memberno="+memberno+"&depno="+depno;
  post_data         = "actions=patient_claims&user_id="+user_id+"&memberno="+memberno+"&depno="+depno;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading;
              $('.load-content').scrollTop(0);              
              $('.load-content').load("template/patient_claims.html", function(){ 
                tab_history[tab_history.length] = history_;
                $('.flex-heading').html(data.heading);
                $('.datepicker-input').datepicker();
                $("input[name='fromdate']").val(data.fromdate);
                $("input[name='todate']").val(data.todate);
                $("input[name='memberno']").val(data.memberno);
                $("input[name='depno']").val(data.depno);

                if(data.details){
                  listData      = "";
                  $.each(data.details, function(k, v) {
                    listData += '<tr>'+
                                '<td>'+v.name+'</td>'+
                                '<td>'+v.memberno+'</td>'+
                                '<td>'+v.claimno+'</td>'+
                                '<td>'+v.amount+'</td>'+
                                '<td>'+v.date+'</td>'+
                                '<td>'+v.view+'</td>'+
                                '</tr>';
                  });
                  $(".claims-grid").html(listData);
                  $(".claims-table").DataTable({
                    "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
                    "sPaginationType": "full_numbers"
                  });
                }           
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function patient_claims_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  if (data){
    switch(data.query_status){
      case 0:
        load_modal(err_string(data.msg), "ERROR");
        break;
      case 1:
        document.title = data.heading;
        $('.flex-heading').html(data.heading);
        $("input[name='fromdate']").val(data.fromdate);
        $("input[name='todate']").val(data.todate);
        if(data.details){
          listData      = "";
          $.each(data.details, function(k, v) {
            listData += '<tr>'+
                        '<td>'+v.name+'</td>'+
                        '<td>'+v.memberno+'</td>'+
                        '<td>'+v.claimno+'</td>'+
                        '<td>'+v.amount+'</td>'+
                        '<td>'+v.date+'</td>'+
                        '<td>'+v.view+'</td>'+
                        '</tr>';
          });
          $(".claims-grid").html(listData);
          $(".claims-table").DataTable({
            "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
            "sPaginationType": "full_numbers"
          });
        }    
        break;
      case 2: 
        break;
    }
  }else{
    load_modal(err_string("ERROR PROCESSING YOUR REQUEST. PLEASE TRY LATER."), "PERMISSIONS");
  } 
}

function claim_details_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "id"){
      var id = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  pageLoadingShow();
  history_          = "claims_details=id"+id;
  post_data         = "actions=claim_details&user_id="+user_id+"&claimno="+id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading;                            
              $('.load-content').load("template/claim_details.html", function(){ 
                tab_history[tab_history.length] = history_;
                $('.load-content').scrollTop(0);
                $('.flex-heading').html(data.heading);

                if(data.details){
                  listData      = "";
                  $.each(data.details, function(k, v) {
                    listData += '<tr>'+
                                '<td>'+v.name+'</td>'+
                                '<td>'+v.memberno+'</td>'+
                                '<td>'+v.suffix+'</td>'+
                                '<td>'+v.provider+'</td>'+
                                '<td>'+v.servicedate+'</td>'+
                                '<td>'+v.clmdescription+'</td>'+
                                '<td>'+v.clmamount+'</td>'+
                                '<td>'+v.optionname+'</td>'+
                                '</tr>';
                  });
                  $(".claims-grid").html(listData);
                }           
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}


//patients
function patients_page(){
  history_       = "patients";
  if(patient_list){
    pageLoadingShow();
    $('.load-content').load("template/patients.html", function(){ 
      tab_history[tab_history.length] = history_;
      pageLoadingHide(); 
      $('.flex-heading').html("PATIENTS");
      listData      = "";
      $.each(patient_list, function(k, v) {
        listData += '<tr>'+
                    '<td>'+v.name+'</td>'+
                    '<td>'+v.memberno+'</td>'+
                    '<td>'+v.suffix+'</td>'+
                    '<td>'+v.gender+'</td>'+
                    '<td>'+v.age+'</td>'+
                    '<td>'+v.plan+'</td>'+
                    '<td>'+v.view+'</td>'+
                    '</tr>';
      });
      $(".members-grid").html(listData);
      $(".members-table").DataTable({
        "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
        "sPaginationType": "full_numbers"
      });           
    });
  }else{
    pageLoadingShow();
    post_data         = "actions=patients&user_id="+user_id;
    $.post(request_url+"?data="+btoa(post_data), function(data) {
      tab_history[tab_history.length] = history;
      pageLoadingHide();      
      try{
        var data = $.parseJSON(data);
        switch(data.query_status) {
            case 0:
                load_modal(err_string(data.msg), data.action_title);
                break;
            case 1:                            
                $('.load-content').load("template/patients.html", function(){ 
                  document.title = "PATIENTS";
                  $('.load-content').scrollTop(0);
                  $('.flex-heading').html(data.heading);

                  if(data.details){
                    patient_list  = data.details;
                    listData      = "";
                    $.each(data.details, function(k, v) {
                      listData += '<tr>'+
                                  '<td>'+v.name+'</td>'+
                                  '<td>'+v.memberno+'</td>'+
                                  '<td>'+v.suffix+'</td>'+
                                  '<td>'+v.gender+'</td>'+
                                  '<td>'+v.age+'</td>'+
                                  '<td>'+v.plan+'</td>'+
                                  '<td>'+v.view+'</td>'+
                                  '</tr>';
                    });
                    $(".members-grid").html(listData);
                    $(".members-table").DataTable({
                      "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
                      "sPaginationType": "full_numbers"
                    });
                  }           
                });
                break;
            case 2:
                load_modal(info_string(data.msg), data.action_title);
                break;
            default:
                load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
        }

      }catch(err){
        load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
      }
    }).fail(function(data) {
      pageLoadingHide();
      
      load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
    });
  }
}

//medical aid providers

function medicalaid_providers_page(){
  pageLoadingShow();
  history_          = "medicalaid_providers";
  post_data         = "actions=medicalaid_providers&user_id="+user_id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading;              
              $('.load-content').load("template/medicalaid_providers.html", function(){ 
                tab_history[tab_history.length] = history_;
                $('.load-content').scrollTop(0);
                $('.flex-heading').html(data.heading);

                if(data.details){
                  listData      = "";
                  $.each(data.details, function(k, v) {
                    listData += '<tr>'+
                                '<td>'+v.name+'</td>'+
                                '<td>'+v.view+'</td>'+
                                '</tr>';
                  });
                  $(".details-grid").html(listData);
                  $(".details-table").DataTable({
                    "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
                    "sPaginationType": "full_numbers"
                  });
                }           
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function medicalaid_provider_details_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "id"){
      var id = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  pageLoadingShow();
  history_          = "medicalaid_provider_details?id="+id;
  post_data         = "actions=medicalaid_provider_details&user_id="+user_id+"&id="+id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading.toUpperCase();
                            
              $('.load-content').load("template/medicalaid_provider_details.html", function(){ 
                tab_history[tab_history.length] = history_;
                $('.load-content').scrollTop(0);
                $('.flex-heading').html(data.heading.toUpperCase());

                if(data.details){
                  $("input[name='id']").val(data.details.id);
                  $("input[name='name']").val(data.details.name);
                }           
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function medicalaid_providers_create_page(){
  $('.load-content').load("template/medicalaid_providers_create.html", function(){            
    tab_history[tab_history.length] = "medicalaid_providers_create";
  });
}

function medicalaid_providers_create_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  if (data){
    switch(data.query_status){
      case 0:
        load_modal(err_string(data.msg), "ERROR");
        break;
      case 1:
        load_modal(success_string(data.msg), data.action_title);
        $("#"+data.actions).not(".ignore").trigger("reset");
        break;
      case 2:
        load_modal(info_string(data.msg), data.action_title);     
        break;
    }
  }else{
    load_modal(err_string("ERROR PROCESSING YOUR REQUEST. PLEASE TRY LATER."), "PERMISSIONS");
  } 
}

function medicalaid_providers_update_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  if (data){
    switch(data.query_status){
      case 0:
        load_modal(err_string(data.msg), "ERROR");
        break;
      case 1:
        load_modal(success_string(data.msg), data.action_title);
        break;
      case 2:
        load_modal(info_string(data.msg), data.action_title);     
        break;
    }
  }else{
    load_modal(err_string("ERROR PROCESSING YOUR REQUEST. PLEASE TRY LATER."), "PERMISSIONS");
  } 
}

//service providers

function add_service_provider(){
  pageLoadingShow();
  history_          = "add_service_provider";
  $('.load-content').load("template/add_service_provider.html", function(){ 
    tab_history[tab_history.length] = history_;
    pageLoadingHide();           
  });
}

function service_providers_page(){
  pageLoadingShow();
  history_          = "service_providers";
  post_data         = "actions=service_providers&user_id="+user_id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading;              
              $('.load-content').load("template/service_providers.html", function(){ 
                tab_history[tab_history.length] = history_;
                
                $('.load-content').scrollTop(0);
                $('.flex-heading').html(data.heading);

                if(data.details){
                  listData      = "";
                  $.each(data.details, function(k, v) {
                    listData += '<tr>'+
                                '<td>'+v.provider+'</td>'+
                                '<td>'+v.practiceno+'</td>'+
                                '<td>'+v.view+'</td>'+
                                '</tr>';
                  });
                  $(".details-grid").html(listData);
                  $(".details-table").DataTable({
                    "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
                    "sPaginationType": "full_numbers"
                  });
                }           
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function service_provider_claims_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "practiceno"){
      var practiceno = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  pageLoadingShow();
  history_          = "service_provider_claims?practiceno="+practiceno;
  post_data         = "actions=service_provider_claims&user_id="+user_id+"&practiceno="+practiceno;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading.toUpperCase();
                            
              $('.load-content').load("template/service_providers_claims.html", function(){ 
                tab_history[tab_history.length] = history_;
                $('.load-content').scrollTop(0);
                $('.flex-heading').html(data.heading.toUpperCase());
                $('.datepicker-input').datepicker();
                $("input[name='practiceno']").val(data.practiceno);
                $("input[name='fromdate']").val(data.fromdate);
                $("input[name='todate']").val(data.todate);
                console.log(data);
                if(data.details){                  
                  listData      = "";
                  $.each(data.details, function(k, v) {
                    listData += '<tr>'+
                                '<td>'+v.name+'</td>'+
                                '<td>'+v.memberno+'</td>'+
                                '<td>'+v.claimno+'</td>'+
                                '<td>'+v.amount+'</td>'+
                                '<td>'+v.date+'</td>'+
                                '<td>'+v.view+'</td>'+
                                '</tr>';
                  });
                  $(".claims-grid").html(listData);
                  $(".claims-table").DataTable({
                    "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
                    "sPaginationType": "full_numbers"
                  });
                }           
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function service_provider_claims_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  if (data){
    switch(data.query_status){
      case 0:
        load_modal(err_string(data.msg), "ERROR");
        break;
      case 1:
        document.title = data.heading;
        $('.flex-heading').html(data.heading);
        $("input[name='practiceno']").val(data.practiceno);
        $("input[name='fromdate']").val(data.fromdate);
        $("input[name='todate']").val(data.todate);

        if(data.details){
          listData      = "";
          $.each(data.details, function(k, v) {
            listData += '<tr>'+
                        '<td>'+v.name+'</td>'+
                        '<td>'+v.memberno+'</td>'+
                        '<td>'+v.claimno+'</td>'+
                        '<td>'+v.amount+'</td>'+
                        '<td>'+v.date+'</td>'+
                        '<td>'+v.view+'</td>'+
                        '</tr>';
          });
          $(".claims-grid").html(listData);
          $(".claims-table").DataTable({
            "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
            "sPaginationType": "full_numbers"
          });
        }    
        break;
      case 2: 
        break;
    }
  }else{
    load_modal(err_string("ERROR PROCESSING YOUR REQUEST. PLEASE TRY LATER."), "PERMISSIONS");
  } 
}

//wellness days

function wellness_day_create_page(){
  pageLoadingShow();
  history_          = "wellness_day_create";
  $('.load-content').load("template/wellness_day_create.html", function(){ 
    tab_history[tab_history.length] = history_;
    pageLoadingHide(); 
    $('.datepicker-input').datepicker();          
  });
}

function wellness_day_edit_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "id"){
      var id = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  pageLoadingShow();
  history_          = "wellness_day_edit?id="+id;
  post_data         = "actions=wellness_day_form&user_id="+user_id+"&id="+id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading;              
              $('.load-content').load("template/wellness_day_edit.html", function(){ 
                tab_history[tab_history.length] = history_;
                $('.load-content').scrollTop(0);
                $('.flex-heading').html(data.heading);
                $('.datepicker-input').datepicker();
                
                if(data.details){
                  $("input[name='id']").val(data.details.id);
                  $("input[name='name']").val(data.details.name);
                  $("input[name='fromdate']").val(data.details.fromdate);
                  $("input[name='todate']").val(data.details.todate);
                }          
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESSING WELLNESS DAYS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function wellness_days_page(){
  pageLoadingShow();
  history_           = "wellness_days";
  post_data         = "actions=wellness_days&user_id="+user_id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading;              
              $('.load-content').load("template/wellness_days.html", function(){ 
                tab_history[tab_history.length] = history_;
                
                $('.load-content').scrollTop(0);
                $('.flex-heading').html(data.heading);

                if(data.details){
                  listData      = "";
                  $.each(data.details, function(k, v) {
                    listData += '<tr>'+
                                '<td>'+v.name+'</td>'+
                                '<td>'+v.date+'</td>'+
                                '<td>'+v.view+'</td>'+
                                '</tr>';
                  });
                  $(".details-grid").html(listData);
                  $(".details-table").DataTable({
                    "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
                    "sPaginationType": "full_numbers"
                  });
                }           
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESSING WELLNESS DAYS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function delete_wellness_day_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "id"){
      var id = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  $(".delete-progress").removeClass("hide");

  var r = confirm("Are you sure you want to delete this entry?");
  if (r == true) {
      post_data         = "actions=delete_wellness_day&user_id="+user_id+"&id="+id;
      $.post(request_url+"?data="+btoa(post_data), function(data) {
        $(".delete-progress").addClass("hide");

        try{
          var data = $.parseJSON(data);

          switch(data.query_status) {
              case 0:
                  load_modal(err_string(data.msg), "DELETE ENTRY");
                  break;
              case 1:
                  load_modal(success_string(data.msg), "DELETE ENTRY");
                  wellness_day_page();
                  break;
              case 2:
                  load_modal(info_string(data.msg), "DELETE ENTRY");
                  break;
              default:
                  load_modal(err_string("THERE WAS AN ERROR TRYING TO DELETE THIS ENTRY. PLEASE TRY AGAIN LATER"), "ERROR");
          }

        }catch(err){
          load_modal(err_string("THERE WAS AN ERROR TRYING TO DELETE THIS ENTRY. PLEASE TRY AGAIN LATER"), "ERROR");
          retract_menu();
        }
      }).fail(function(data) {
        pageLoadingHide();
        load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
      });
  } else {
      $(".delete-progress").addClass("hide");
  }
}

function wellness_days_report_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "id"){
      var id = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  pageLoadingShow();
  history_           = "wellness_day_report?id="+id;
  post_data         = "actions=wellness_day_report&user_id="+user_id+"&id="+id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              document.title = data.heading.toUpperCase();
                            
              $('.load-content').load("template/wellness_day_report.html", function(){ 
                tab_history[tab_history.length] = history_;
                $('.load-content').scrollTop(0);
                $('.flex-heading').html(data.heading.toUpperCase());
                $('.datepicker-input').datepicker();
                var num_patients = 0;

                if(data.details){                  
                  listData      = "";
                  $.each(data.details, function(k, v) {
                    listData += '<tr>'+
                                '<td>'+v.name+'</td>'+
                                '<td>'+v.memberno+'</td>'+
                                '<td>'+v.bmi+'</td>'+
                                '<td>'+v.bloodsugar+'</td>'+
                                '<td>'+v.bp+'</td>'+
                                '<td>'+v.cholestroral+'</td>'+
                                '<td>'+v.view+'</td>'+
                                '</tr>';
                    num_patients++;
                  });
                  $('.flex-heading').html(data.heading.toUpperCase()+" <b>"+num_patients+" PATIENTS</b>");
                  $(".details-grid").html(listData);
                  $(".details-table").DataTable({
                    "sDom": "<'row'<'col-xs-6'l><'col-xs-6'f>r>t<'row'<'col-xs-6'i><'col-xs-6'p>>",
                    "sPaginationType": "full_numbers"
                  });
                }

                if(data.summary){
                  //bmi
                  $(".bmiunderweight").html(data.summary.underweight);
                  $(".bmihealthy").html(data.summary.healthy);
                  $(".bmioverweight").html(data.summary.overweight);
                  $(".bmiobese").html(data.summary.obese);
                  //cholesterol
                  $(".chloptimal").html(data.summary.optimal);
                  $(".chlintermediate").html(data.summary.intermediate);
                  $(".chlhigh").html(data.summary.high);
                  //bp
                  $(".bphigh").html(data.summary.bphigh);
                  $(".bpprehigh").html(data.summary.bpprehigh);
                  $(".bpnormal").html(data.summary.bpnormal);
                  $(".bplow").html(data.summary.bplow);
                  //bloodsugar
                  $(".bshigh").html(data.summary.bshigh);
                  $(".bslow").html(data.summary.bslow);
                  $(".bsoptimal").html(data.summary.bsoptimal);
                }
              });
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR ACCESS DASHBOARD DETAILS. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function delete_wellness_day_entry_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "id"){
      var id = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  $(".delete-progress").removeClass("hide");

  var r = confirm("Are you sure you want to delete this entry?");
  if (r == true) {
      post_data         = "actions=delete_wellness_day_entry&user_id="+user_id+"&id="+id;
      $.post(request_url+"?data="+btoa(post_data), function(data) {
        $(".delete-progress").addClass("hide");

        try{
          var data = $.parseJSON(data);

          switch(data.query_status) {
              case 0:
                  load_modal(err_string(data.msg), "DELETE ENTRY");
                  break;
              case 1:
                  load_modal(success_string(data.msg), "DELETE ENTRY");
                  wellness_day_page();
                  break;
              case 2:
                  load_modal(info_string(data.msg), "DELETE ENTRY");
                  break;
              default:
                  load_modal(err_string("THERE WAS AN ERROR TRYING TO DELETE THIS ENTRY. PLEASE TRY AGAIN LATER"+data.query_status), "ERROR");
                  break;
          }

        }catch(err){
          load_modal(err_string("THERE WAS AN ERROR TRYING TO DELETE THIS ENTRY. PLEASE TRY AGAIN LATER 123456"+data.query_status), "ERROR");
          retract_menu();
        }
      }).fail(function(data) {
        pageLoadingHide();
        load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
      });
  } else {
      $(".delete-progress").addClass("hide");
  }
}

function wellness_day_create_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  if(data){
    switch(data.query_status){
      case 0:
        load_modal(err_string(data.msg), "ERROR");
        break;
      case 1:
        load_modal(success_string(data.msg), data.action_title);    
        break;
      case 2: 
        load_modal(info_string(data.msg), data.action_title);    
        break;
    }
  }else{
    load_modal(err_string("ERROR PROCESSING YOUR REQUEST. PLEASE TRY LATER."), "PERMISSIONS");
  } 
}

function wellness_day_edit_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  if(data){
    switch(data.query_status){
      case 0:
        load_modal(err_string(data.msg), "ERROR");
        break;
      case 1:
        load_modal(success_string(data.msg), data.action_title);    
        break;
      case 2: 
        load_modal(info_string(data.msg), data.action_title);    
        break;
    }
  }else{
    load_modal(err_string("ERROR PROCESSING YOUR REQUEST. PLEASE TRY LATER."), "PERMISSIONS");
  } 
}

function wellness_day_sms_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "id"){
      var id = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  pageLoadingShow();
  post_data         = "actions=wellness_day_sms&user_id="+user_id+"&id="+id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

function wellness_day_email_page(data){
  var num_variable  = data.length - 1;

  for (i = 0; i <= num_variable; i++){
    if(data[i].substr(0, data[i].indexOf("=")) == "id"){
      var id = data[i].substr(data[i].indexOf("=") + 1, data[i].length);
    }      
  }

  pageLoadingShow();
  post_data         = "actions=wellness_day_email&user_id="+user_id+"&id="+id;
  $.post(request_url+"?data="+btoa(post_data), function(data) {
    pageLoadingHide();      
    try{
      var data = $.parseJSON(data);
      switch(data.query_status) {
          case 0:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 1:
              load_modal(err_string(data.msg), data.action_title);
              break;
          case 2:
              load_modal(info_string(data.msg), data.action_title);
              break;
          default:
              load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. TRY AGAIN LATER"), "ERROR");
      }

    }catch(err){
      load_modal(err_string("THERE WAS AN ERROR PROCESSING YOUR REQUEST. PLEASE TRY AGAIN LATER."), "ERROR");
    }
  }).fail(function(data) {
    pageLoadingHide();
    
    load_modal(err_string("ERROR: PLEASE CHECK YOUR INTERNET CONNECTION"), "CONNECTION");
  });
}

//imports

function import_patient_details_page(){
  pageLoadingShow();
  $('.load-content').load("template/import_patient_details.html", function(){ 
    tab_history[tab_history.length] = "import_patient_details";
    pageLoadingHide();
    $('.flex-heading').html("IMPORT PATIENT DETAILS");
    $('.datepicker-input').datepicker();
    ajax_uploader();           
  });
}

function import_patient_details_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  if (data){
    switch(data.query_status){
      case 0:
        load_modal(err_string(data.msg), "ERROR");
        break;
      case 1:
        load_modal(success_string(data.msg), data.action_title);
        break;
      case 2:
        load_modal(info_string(data.msg), data.action_title);     
        break;
    }
  }else{
    load_modal(err_string("ERROR PROCESSING YOUR REQUEST. PLEASE TRY LATER."), "PERMISSIONS");
  } 
}

function import_patient_claims_page(){
  pageLoadingShow();
  $('.load-content').load("template/import_patient_claims.html", function(){ 
    tab_history[tab_history.length] = "import_patient_claims";
    pageLoadingHide();
    $('.flex-heading').html("IMPORT PATIENT CLAIMS");
    $('.datepicker-input').datepicker();
    ajax_uploader();           
  });
}

function import_patient_claims_result(data){
  $('#submit').prop("disabled", false);
  $('.form-progress').addClass("hide");
  if(data){
    switch(data.query_status){
      case 0:
        load_modal(err_string(data.msg), "ERROR");
        break;
      case 1:
        load_modal(success_string(data.msg), data.action_title);
        break;
      case 2:
        load_modal(info_string(data.msg), data.action_title);     
        break;
    }
  }else{
    load_modal(err_string("ERROR PROCESSING YOUR REQUEST. PLEASE TRY LATER."), "PERMISSIONS");
  } 
}

$(document).on('keyup', '#medaidnumber_', function(e) {
  var num_string    = $(this).val().length;
  var keywords      = $(this).val();
  var search_list   = "";

  if(num_string >= 2 ){
    $.post(search_url+"?user_id="+user_id+"&term="+keywords, function(data) {
        var info = $.parseJSON(data);  
        $.each(info, function(k, v) { 
          search_list +=  '<a data-link="user_details.php?id='+v.id+'&user_id='+user_id+'" href="#" class="list-group-item">'+
                          '<i class="fa fa-chevron-right icon-muted"></i>'+
                          '<i class="fa fa-user icon-muted fa-fw"></i> '+v.label+
                          '</a>'
        });
        $("#search_results").html(search_list);
      }).fail(function(data) {
        search_list +=  '<a href="#" class="list-group-item">'+
                          '<i class="fa fa-chevron-right icon-muted"></i>'+
                          '<i class="fa fa-user icon-muted fa-fw"></i> ERROR SEARCHING'+
                          '</a>'
        $("#search_results").html(search_list); 
      });    
    }
});

$(document).on('blur', '#medaidnumber', function(e) {
  $("#user-search").removeClass('ui-autocomplete-loading').val('');
});

function load_graph(div, data){
  var xaxis = [];
  var yaxis = [];
  var i     = 0; 

  $.each(data.xaxis, function(k, v) {
    xaxis.push([k, v]);    
  });

  $.each(data.yaxis, function(k, v) {
    yaxis.push([k, v]);    
  });

  $(div).length && $.plot($(div), [{
          data: yaxis
      }], 
      {
        series: {
            lines: {
                show: true,
                lineWidth: 2,
                fill: true,
                fillColor: {
                    colors: [{
                        opacity: 0.0
                    }, {
                        opacity: 0.2
                    }]
                }
            },
            points: {
                radius: 3,
                show: true
            },
            shadowSize: 2
        },
        grid: {
            hoverable: true,
            clickable: true,
            tickColor: "#f0f0f0",
            borderWidth: 1,
            color: '#f0f0f0'
        },
        colors: ["#65bd77"],
        xaxis:{
          ticks: xaxis,
          tickDecimals: 0
        },
        yaxis: {
          ticks: 10,
          tickDecimals: 0
        },
        tooltip: true,
        tooltipOpts: {
          content: "%y",
          defaultTheme: false,
          shifts: {
            x: 0,
            y: 20
          }
        }
      }
  );
}