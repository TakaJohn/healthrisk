//simple list group
$.each(data, function(k, v) {
  listData += '<li class="list-group-item">'+
                '<a href="#" data-link="function?id='+v.id+'&name='+v.name+'">'+
                  '<div class="media">'+
                    '<div class="pull-right text-success m-t-sm"><i class="fa fa-circle"></i></div>'+
                    '<div class="media-body">'+
                      '<div>'+v.name+'</div>'+
                    '</div>'+
                  '</div>'+
                '</a>'+
              '</li>';
  x++;
});

$(".simple-list").html(listData);

//thumbnail list group
$.each(data, function(k, v) {
  listData += '<li class="list-group-item">'+
                '<a href="#" data-link="function?id='+v.id+'&name='+v.name+'">'+
                  '<div class="media">'+
                    '<span class="pull-left thumb-sm"><img src="images/avatar.jpg" alt="" class="img-circle"></span>'+
                    '<div class="pull-right text-success m-t-sm"><i class="fa fa-circle"></i></div>'+
                    '<div class="media-body">'+
                      '<div>'+v.name+'</div>'+
                      '<small class="text-muted">about 2 minutes ago</small>'+
                    '</div>'+
                  '</div>'+
                '</a>'+
              '</li>';
  x++;
});

$(".thumbnail-list").html(listData);

//article list group
$.each(data, function(k, v) {
  listData += '<article class="media">'+
                '<span class="pull-left thumb-md"><img src="'+img+'"></span>'+ // image
                //'<i class="fa fa-file-o fa-3x icon-muted"></i>'+ // article
                '<div class="media-body">'+
                  '<div class="pull-right media-xs text-center text-muted">'
                    '<strong class="h4">17</strong><br>'
                    '<small class="label bg-light">feb</small>'
                  '</div>'
                  '<h4>'+title+'</h4>'+
                  '<small class="block">'+client+'<span class="label label-info">Friends</span></small>'+
                  '<small class="block m-t-sm">'+msg+'</small>'+
                '</div>'+
              '</article>';
  x++;
});

$(".thumbnail-list").html(listData);

//datatable
$('[data-ride="datatables"]').each(function() {
  var oTable = $(this).dataTable( {
    "bProcessing": true,
    "sAjaxSource": "js/data/datatable.json",
    "sDom": "<'row'<'col-sm-6'l><'col-sm-6'f>r>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
    "sPaginationType": "full_numbers",
    "aoColumns": [
      { "mData": "engine" },
      { "mData": "browser" },
      { "mData": "platform" },
      { "mData": "version" },
      { "mData": "grade" }
    ]
  } );
});